import default
print"### Starting Global Update Check"
default.Check_Update_Launcher('')