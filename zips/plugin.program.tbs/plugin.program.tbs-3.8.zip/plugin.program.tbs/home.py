import sys
import os
import xbmc
import xbmcgui
import yt
import default

dialog  = xbmcgui.Dialog()
tvguide = xbmc.translatePath('special://home/userdata/addon_data/script.tvportal.tools/skip.txt')
try:
    avivfile = open(xbmc.translatePath('special://home/userdata/addon_data/plugin.video.tfctv/settings.xml'),'r')
    readfile = avivfile.read()
    avivfile.close()

    if 'aviv4494' in readfile:
        tvgskip = 1
    else:
        tvgskip = 0
except:
        tvgskip = 0

sys.argv[1] = sys.argv[1].replace("'",'')
print"ARGV 1: "+sys.argv[1]

cleanname = sys.argv[1].replace("HOME_",'')
cleanname = cleanname.lower()

def foldercheck(path):
    directories = 0
    folderpath = xbmc.translatePath(os.path.join('special://profile/addon_data/plugin.program.super.favourites/Super Favourites/',sys.argv[1]))
    for dirs in os.walk(folderpath):
        directories += len(dirs[1])
    xbmc.log("### Dirs: "+str(directories))
    return directories

folders = foldercheck(sys.argv[1])
if folders == 0:
    default.pop('nocontent.xml')
    xbmc.executebuiltin("RunScript(special://home/addons/plugin.program.tbs/epg.py,"+cleanname+")")

elif sys.argv[1] == "HOME_LIVE_TV" and not os.path.exists(tvguide) and tvgskip == 0:
    xbmc.executebuiltin('RunScript(script.tvportal)')
    
else:
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.super.favourites/?folder='+sys.argv[1]+'",return)')