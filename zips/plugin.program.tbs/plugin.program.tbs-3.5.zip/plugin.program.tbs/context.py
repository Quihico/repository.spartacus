import sys
import re
import os
import xbmc
import xbmcgui
import urllib2
import urllib
import time
import downloader
from default import encryptme as encryptme

dialog        = xbmcgui.Dialog()
flist         = xbmc.translatePath('special://profile/addon_data/plugin.program.tbs/flist')
log_path      =  xbmc.translatePath('special://logpath/')
xbmc_version  = xbmc.getInfoLabel("System.BuildVersion")

if not os.path.exists(flist):
    newfile = open(flist,'w')
    newfile.close()

readfile = open(flist,'r')
MasterList = readfile.read().replace('\n','')
readfile.close()

FriendList = MasterList.split('|')

print"### Friends: "+str(FriendList)

def getMacAddress(protocol):
    if sys.platform == 'win32': 
        for line in os.popen("ipconfig /all"): 
            if line.lstrip().startswith('Physical Address'): 
                mac = line.split(':')[1].strip().replace('-',':')
                break 

    if xbmc.getCondVisibility('System.Platform.Android'):
        if protcol == 'wifi':
            readfile = open('/sys/class/net/wlan0/address', mode='r')
        else:
            readfile = open('/sys/class/net/eth0/address', mode='r')
        mac = readfile.read()
        mac = mac[:17]
        readfile.close()

    else:
        if protocol == 'wifi':
            for line in os.popen("/sbin/ifconfig"): 
                if line.find('wlan0') > -1: 
                    mac = line.split()[4] 
                    break
        else:
           for line in os.popen("/sbin/ifconfig"): 
                if line.find('eth0') > -1: 
                    mac = line.split()[4] 
                    break
    return str(mac)

def Build_Info():
    version=str(xbmc_version[:2])
    if version < 14:
        logfile = os.path.join(log_path, 'xbmc.log')
    
    else:
        logfile = os.path.join(log_path, 'kodi.log')

    filename    = open(logfile, 'r')
    logtext     = filename.read()
    filename.close()

    Buildmatch  = re.compile('Running on (.+?)\n').findall(logtext)
    Build       = Buildmatch[0] if (len(Buildmatch) > 0) else ''
    return Build.replace(' ','%20')

def CPU_Check():
    version=str(xbmc_version[:2])
    if version < 14:
        logfile = os.path.join(log_path, 'xbmc.log')
    
    else:
        logfile = os.path.join(log_path, 'kodi.log')

    filename    = open(logfile, 'r')
    logtext     = filename.read()
    filename.close()

    CPUmatch    = re.compile('Host CPU: (.+?) available').findall(logtext)
    CPU         = CPUmatch[0] if (len(CPUmatch) > 0) else ''
    return CPU.replace(' ','%20')

def URL_Params():
        try:
            wifimac = getMacAddress('wifi').replace('\r','').replace('\n','').replace('\t','')
        except:
            wifimac = 'Unknown'
        try:
            ethmac  = getMacAddress('eth0').replace('\r','').replace('\n','').replace('\t','')
        except:
            ethmac  = 'Unknown'
        try:
            cpu     = CPU_Check().replace('\r','').replace('\n','').replace('\t','')
        except:
            cpu     = 'Unknown'
        try:
            build   = Build_Info().replace('\r','').replace('\n','').replace('\t','')
        except:
            build   = 'Unknown'

        urlparams = wifimac+'&'+cpu+'&'+build+'&'+ethmac.replace(' ','%20')
        return urlparams

def Choose_Friends():
    choice = dialog.select('Choose friend to share with',FriendList)

def Open_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link     = response.read()
    response.close()
    if link=='':
        link='no response'
    return link
    
def Open_URL2(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    try:
        response = urllib2.urlopen(req, timeout = 30)
    except:
        response = 'no response'
#        try:
#            response = urllib2.urlopen(req, timeout = 5)
#        except:
#            try:
#                response = urllib2.urlopen(req, timeout = 5)
#            except:
#                response = 'no response'
    if response != 'no response':
        link     = response.read()
        response.close()
    else:
       link = 'no response'
        
    return link.replace('\r','').replace('\n','').replace('\t','')
 
if __name__ == '__main__':
    choice         = 0
    urlparams      = URL_Params()
    item           = sys.listitem.getLabel()
    item           = item.replace('[COLOR ]','').replace('[/COLOR]','')
    path           = xbmc.getInfoLabel('ListItem.FolderPath')
    path           = urllib.unquote(path)#.replace('%2f','/').replace('%20',' ').replace('%3a',':')
    try:
        scrap,fullpath = path.split('path=')
#        print"### fullpath: "+str(fullpath)
        fullpath       = xbmc.translatePath(fullpath)
    except:
        fullpath = "not a SF"
    try:
        scrap,newpath  = path.split('path=special://profile/addon_data/plugin.program.super.favourites/Super Favourites/')
#        print"### newpath: "+str(newpath)
    except:
        try:
#            print"### translated: "+xbmc.translatePath('special://profile/addon_data/plugin.program.super.favourites/Super Favourites/')
            scrap,newpath  = path.split('path='+urllib.unquote(xbmc.translatePath('special://profile/addon_data/plugin.program.super.favourites/Super Favourites/')))
#            print"### newpath: "+str(newpath)
        except:
            newpath  = "not a SF"
        newpath = newpath.replace('\\','/')

    if os.path.exists(os.path.join(fullpath,'favourites.xml')):
        xmlfile  = open(os.path.join(fullpath,'favourites.xml'),'r')
        xml = xmlfile.read()
        xml = xml.replace(xbmc.translatePath('special://home'),'special://home/').replace(urllib.quote(xbmc.translatePath('special://home').encode("utf-8")),'special://home/').replace('\r','').replace('\n','').replace('\t','')
        xmlfile.close()
#        print "### XML FILE: "+xml
    else:
        xml="not a SF"

    try:
        cfgfile=open(os.path.join(fullpath,'folder.cfg'),'r')
        cfg = cfgfile.read()
        cfg = cfg.replace('\r','').replace('\n','').replace('\t','')
        cfgfile.close()
    except:
        cfg=''

#    print"### CFG FILE: "+cfg
    
    try:
        pluginname=xbmc.getInfoLabel('Container.PluginName')
        print"### plugin name: "+str(pluginname)
    except:
        pluginname='none'

    quit = 0
    if pluginname == 'plugin.program.super.favourites':
#        choice = dialog.select('Choose Share Type',['Share with a friend','Share publicly','Add to my private share'])
        choice = dialog.select('Choose Share Type',['Share publicly','Add to my private share'])
        if xml == "not a SF":
            dialog.ok('Empty Folder','This folder doesn\'t contain any content. Please populate with content and try again.')
            quit = 1
        if choice == 0 and quit != 1:
#            print'http://tlbb.me/boxer/share.php?x='+encryptme('e',urlparams)+'&z=gs&k='+encryptme('e',xml)+'&c='+encryptme('e',cfg)+'&p='+encryptme('e',newpath)
            try:
                sendfaves = Open_URL2('http://tlbb.me/boxer/share.php?x='+encryptme('e',urlparams)+'&z=gs&k='+encryptme('e',xml)+'&c='+encryptme('e',cfg)+'&p='+encryptme('e',newpath))
                if 'success' in sendfaves:
                    dialog.ok('Content Submitted', 'Thank you for sharing with the community.',item+' has now been shared and is publicly available.')
                elif 'no response' in sendfaves:
                    dialog.ok(item.capitalize()+' Not Submitted', 'There was an error trying to contact the server, please try again later.')
                elif 'Too Long' in sendfaves:
                    dialog.ok(item.capitalize()+' Not Submitted', 'Super Favourites contents are too large, please trim down in size and try again.')
            except:
                dialog.ok(item.capitalize()+' Not Submitted', 'There was an error trying to add your content, please try again.')
        if choice == 1 and quit != 1:
            dialog.ok('Work In Progress','Sorry the private content section is currently a work in progress. Please check back soon.')
#    if pluginname != 'plugin.program.super.favourites' or choice == 0:
#        Choose_Friends()
    if pluginname != 'plugin.program.super.favourites' and quit != 1:
        xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.super.favourites/capture.py)')
#        dialog.ok('Not Yet Available','Currently the sharing menu can only be used from Super Favourites. New features will be unlocked over the coming months so check back soon!')
    

#    message = "Clicked on '%s'" % sys.listitem.getLabel()
#    print"Item: "+item
#    print"Location: "+xbmc.getInfoLabel('Container.FolderPath')
#    print"Path: "+xbmc.getInfoLabel('ListItem.FolderPath')
#    print"Addon_ID: "+xbmc.getInfoLabel('Container.PluginName')
#    xbmc.executebuiltin("Notification(\"Hello context items!\", \"%s\")" % message)