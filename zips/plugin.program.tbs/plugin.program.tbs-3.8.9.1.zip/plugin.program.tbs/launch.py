import default

default.Launch()