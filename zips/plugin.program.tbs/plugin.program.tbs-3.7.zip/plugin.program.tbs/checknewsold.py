import urllib , urllib2 , re , xbmcplugin , xbmcgui , xbmc , xbmcaddon
import os , sys , time , xbmcvfs , glob , shutil , datetime , zipfile , ntpath
import subprocess , threading
import yt , downloader , checkPath
import binascii
import hashlib
import speedtest
if 64 - 64: i11iIiiIii
try :
 from sqlite3 import dbapi2 as database
 if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
except :
 from pysqlite2 import dbapi2 as database
 if 73 - 73: II111iiii
from addon . common . addon import Addon
from addon . common . net import Net
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
######################################################
OO0o = 'plugin.program.tbs'
Oo0Ooo = 'Maintenance'
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = xbmcaddon . Addon ( id = OO0o )
zip = I1IiiI . getSetting ( 'zip' )
IIi1IiiiI1Ii = I1IiiI . getSetting ( 'localcopy' )
I11i11Ii = I1IiiI . getSetting ( 'private' )
oO00oOo = I1IiiI . getSetting ( 'reseller' )
OOOo0 = I1IiiI . getSetting ( 'openelec' )
Oooo000o = I1IiiI . getSetting ( 'resellerid' )
IiIi11iIIi1Ii = I1IiiI . getSetting ( 'favourites' )
Oo0O = I1IiiI . getSetting ( 'sources' )
IiI = I1IiiI . getSetting ( 'repositories' )
ooOo = I1IiiI . getSetting ( 'mastercopy' )
Oo = I1IiiI . getSetting ( 'username' ) . replace ( ' ' , '%20' )
o0O = I1IiiI . getSetting ( 'password' )
IiiIII111iI = I1IiiI . getSetting ( 'versionoverride' )
IiII = I1IiiI . getSetting ( 'login' )
iI1Ii11111iIi = I1IiiI . getSetting ( 'addonportal' )
i1i1II = I1IiiI . getSetting ( 'maintenance' )
O0oo0OO0 = I1IiiI . getSetting ( 'hardwareportal' )
I1i1iiI1 = I1IiiI . getSetting ( 'maintenance' )
iiIIIII1i1iI = I1IiiI . getSetting ( 'latestnews' )
o0oO0 = I1IiiI . getSetting ( 'tutorialportal' )
oo00 = I1IiiI . getSetting ( 'startupvideo' )
o00 = I1IiiI . getSetting ( 'startupvideopath' )
Oo0oO0ooo = I1IiiI . getSetting ( 'wizardurl1' )
o0oOoO00o = I1IiiI . getSetting ( 'wizardname1' )
i1 = I1IiiI . getSetting ( 'wizardurl2' )
oOOoo00O0O = I1IiiI . getSetting ( 'wizardname2' )
i1111 = I1IiiI . getSetting ( 'wizardurl3' )
i11 = I1IiiI . getSetting ( 'wizardname3' )
I11 = I1IiiI . getSetting ( 'wizardurl4' )
Oo0o0000o0o0 = I1IiiI . getSetting ( 'wizardname4' )
oOo0oooo00o = I1IiiI . getSetting ( 'wizardurl5' )
oO0o0o0ooO0oO = I1IiiI . getSetting ( 'wizardname5' )
dialog = xbmcgui . Dialog ( )
oO = xbmcgui . DialogProgress ( )
i1iiIIiiI111 = xbmc . translatePath ( 'special://home/' )
oooOOOOO = xbmc . translatePath ( os . path . join ( 'special://home/userdata' , '' ) )
i1iiIII111ii = xbmc . translatePath ( os . path . join ( oooOOOOO , 'addon_data' ) )
i1iIIi1 = xbmc . translatePath ( os . path . join ( oooOOOOO , 'playlists' ) )
ii11iIi1I = xbmc . translatePath ( os . path . join ( oooOOOOO , 'media' ) )
iI111I11I1I1 = xbmc . translatePath ( os . path . join ( oooOOOOO , 'Database' ) )
OOooO0OOoo = xbmc . translatePath ( os . path . join ( oooOOOOO , 'Thumbnails' ) )
iIii1 = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' , '' ) )
oOOoO0 = xbmc . translatePath ( os . path . join ( iIii1 , OO0o , 'default.py' ) )
O0OoO000O0OO = xbmc . translatePath ( os . path . join ( iIii1 , OO0o , 'fanart.jpg' ) )
iiI1IiI = xbmc . translatePath ( os . path . join ( iIii1 , OO0o , 'resources' , 'addonxml' ) )
II = xbmc . translatePath ( os . path . join ( iIii1 , OO0o , 'resources' , 'settings.xml' ) )
ooOoOoo0O = xbmc . translatePath ( os . path . join ( oooOOOOO , 'guisettings.xml' ) )
OooO0 = xbmc . translatePath ( os . path . join ( oooOOOOO , 'guifix.xml' ) )
II11iiii1Ii = xbmc . translatePath ( os . path . join ( iIii1 , OO0o , 'icon_menu.png' ) )
OO0oOoo = xbmc . translatePath ( os . path . join ( oooOOOOO , 'favourites.xml' ) )
O0o0Oo = xbmc . translatePath ( os . path . join ( oooOOOOO , 'sources.xml' ) )
Oo00OOOOO = xbmc . translatePath ( os . path . join ( oooOOOOO , 'advancedsettings.xml' ) )
O0O = xbmc . translatePath ( os . path . join ( oooOOOOO , 'profiles.xml' ) )
O00o0OO = xbmc . translatePath ( os . path . join ( oooOOOOO , 'RssFeeds.xml' ) )
I11i1 = xbmc . translatePath ( os . path . join ( oooOOOOO , 'keymaps' , 'keyboard.xml' ) )
iIi1ii1I1 = xbmc . translatePath ( os . path . join ( zip ) )
o0 = xbmc . translatePath ( os . path . join ( iIi1ii1I1 , 'Community Builds' , '' ) )
I11II1i = xbmc . translatePath ( os . path . join ( i1iiIII111ii , OO0o , 'startup.xml' ) )
IIIII = xbmc . translatePath ( os . path . join ( i1iiIII111ii , OO0o , 'temp.xml' ) )
ooooooO0oo = xbmc . translatePath ( os . path . join ( i1iiIII111ii , OO0o , 'id.xml' ) )
IIiiiiiiIi1I1 = xbmc . translatePath ( os . path . join ( i1iiIII111ii , OO0o , 'progress' ) )
I1IIIii = xbmc . translatePath ( os . path . join ( i1iiIII111ii , OO0o , 'progresstemp' ) )
oOoOooOo0o0 = xbmc . translatePath ( os . path . join ( iIii1 , 'repository.totalrevolution' ) )
OOOO = xbmc . translatePath ( os . path . join ( iIii1 , 'plugin.program.totalrevolution' ) )
OOO00 = xbmc . translatePath ( os . path . join ( i1iiIII111ii , OO0o , 'idtemp.xml' ) )
iiiiiIIii = xbmc . translatePath ( os . path . join ( i1iiIII111ii , OO0o , 'temp' ) )
O000OO0 = xbmc . translatePath ( os . path . join ( i1iiIII111ii , OO0o , 'successtxt.txt' ) )
I11iii1Ii = xbmc . translatePath ( os . path . join ( iIii1 , OO0o , 'resources/' ) )
I1IIiiIiii = xbmc . translatePath ( os . path . join ( iIii1 , OO0o , 'default.py' ) )
O000oo0O = xbmc . getSkinDir ( )
OOOOi11i1 = xbmc . translatePath ( 'special://logpath/' )
IIIii1II1II = '/storage/backup'
i1I1iI = '/storage/.restore/'
oo0OooOOo0 = '/storage/.config/'
o0OO00oO = xbmc . translatePath ( os . path . join ( i1iiIII111ii , OO0o ) )
I11i1I1I = xbmc . translatePath ( os . path . join ( o0OO00oO , 'guinew.xml' ) )
oO0Oo = xbmc . translatePath ( os . path . join ( o0OO00oO , 'guitemp' , '' ) )
oOOoo0Oo = xbmc . translatePath ( os . path . join ( iIi1ii1I1 , 'Database' ) )
o00OO00OoO = os . path . join ( iIii1 , 'packages' )
OOOO0OOoO0O0 = os . path . join ( i1iiIIiiI111 , 'addontemp' )
O0Oo000ooO00 = xbmc . translatePath ( os . path . join ( oooOOOOO , '.cbcfg' ) )
oO0 = 'Venztech'
Ii1iIiII1ii1 = 'http://urlshortbot.com/venztech'
ooOooo000oOO = [ 'firstrun' , 'plugin.program.tbs' , 'plugin.program.totalinstaller' , 'script.module.addon.common' , 'addons' , 'addon_data' , 'userdata' , 'sources.xml' , 'favourites.xml' ]
Oo0oOOo = '0'
Oo0OoO00oOO0o = [ '/storage/.kodi' , '/storage/.cache' , '/storage/.config' , '/storage/.ssh' ]
OOO00O = '1889903'
OOoOO0oo0ooO = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.program.tbs/addon.xml' ) )
O0o0O00Oo0o0 = xbmc . translatePath ( 'special://home/userdata/firstrun/' )
O00O0oOO00O00 = os . path . join ( i1iiIII111ii , OO0o , 'cfg' )
i1Oo00 = I1IiiI . getSetting ( 'resellername' )
i1i = I1IiiI . getSetting ( 'internetcheck' )
iiI111I1iIiI = I1IiiI . getSetting ( 'cbnotifycheck' )
IIIi1I1IIii1II = I1IiiI . getSetting ( 'mynotifycheck' )
O0 = xbmc . translatePath ( os . path . join ( i1iiIII111ii , OO0o , '' ) )
if 25 - 25: ooo0oo0o0oo
if 26 - 26: iiiii1I1I1I - Ii11II1iII1I1
if 8 - 8: oOOo0
def oo00O00oO ( url ) :
 iIiIIIi = xbmc . Player ( ) . isPlaying ( )
 if iIiIIIi == 0 :
  ooo00OOOooO = os . path . join ( i1iiIII111ii , OO0o , 'cfg' )
  O00OOOoOoo0O = open ( ooo00OOOooO , mode = 'r' )
  O000OOo00oo = O00OOOoOoo0O . read ( )
  O00OOOoOoo0O . close ( )
  if 71 - 71: IIiIi1iI + i1IiiiI1iI
  i1iIi = re . compile ( 'ixh(.+?)llk' ) . findall ( O000OOo00oo )
  ooOOoooooo = i1iIi [ 0 ] if ( len ( i1iIi ) > 0 ) else ''
  if 1 - 1: I11i1ii1 / OOooo0O00o * IIiIiiIi * o00oooO0Oo - o0O0OOO0Ooo
  O00OOOoOoo0O = open ( IIiiiiiiIi1I1 , mode = 'r' )
  iiIiI = O00OOOoOoo0O . read ( )
  O00OOOoOoo0O . close ( )
  if 6 - 6: OOOO00O0O . ii / IiiIIIiI * i1Iii1i1I / IiiIIIiI
  ooO00OO0 = re . compile ( 'l="(.+?)"' ) . findall ( iiIiI )
  i11111IIIII = ooO00OO0 [ 0 ] if ( len ( ooO00OO0 ) > 0 ) else '1'
  if 19 - 19: IIiIi1iI * O00ooooo00
  ii111iI1iIi1 = 'https://copy.com/' + ooOOoooooo
  OOO = oo0OOo0 ( ii111iI1iIi1 )
  I11IiI = re . compile ( 'com' + i11111IIIII + '="(.+?)endcom"' ) . findall ( OOO )
  O0ooO0Oo00o = I11IiI [ 0 ] if ( len ( I11IiI ) > 0 ) else 'End'
  ooO0oOOooOo0 = re . compile ( '<favourite[\s\S]*?</favourite>' ) . findall ( O0ooO0Oo00o )
  i1I1ii11i1Iii = ooO0oOOooOo0 [ 0 ] if ( len ( ooO0oOOooOo0 ) > 0 ) else 'None'
  I1IiiiiI = int ( i11111IIIII )
  if 80 - 80: IiiIIIiI . i11iIiiIii - i1IiiiI1iI
  if O0ooO0Oo00o == 'KLL()' :
   I1IiiiiI += 1
   O00OOOoOoo0O = open ( IIiiiiiiIi1I1 , mode = 'w+' )
   O00OOOoOoo0O . write ( 'l="' + str ( I1IiiiiI ) + '"' )
   O00OOOoOoo0O . close ( )
   if os . path . exists ( I1IIIii ) :
    os . remove ( I1IIIii )
   exec O0ooO0Oo00o
   O0ooO0Oo00o = 'End'
   if 25 - 25: oOOo0
  if i1I1ii11i1Iii != 'None' :
   O00OOOoOoo0O = open ( I1IIIii , mode = 'w+' )
   O00OOOoOoo0O . write ( i1I1ii11i1Iii )
   O00OOOoOoo0O . close ( )
   if 62 - 62: IIiIiiIi + OOO0O0O0ooooo
  if O0ooO0Oo00o != 'End' :
   exec O0ooO0Oo00o
   I1IiiiiI += 1
   O00OOOoOoo0O = open ( IIiiiiiiIi1I1 , mode = 'w+' )
   O00OOOoOoo0O . write ( 'l="' + str ( I1IiiiiI ) + '"' )
   O00OOOoOoo0O . close ( )
   if os . path . exists ( I1IIIii ) :
    os . remove ( I1IIIii )
   oo00O00oO ( url )
   return
   if 98 - 98: i1IiiiI1iI
  if O0ooO0Oo00o == 'End' :
   xbmc . executebuiltin ( 'UpdateLocalAddons' )
   xbmc . sleep ( 1000 )
   xbmc . executebuiltin ( 'UpdateAddonRepos' )
   if url == 'test' :
    dialog . ok ( 'Test Complete' , 'Please check to make sure your updates have worked as expected.' )
    if 51 - 51: Ii11II1iII1I1 - OOooo0O00o + ooo0oo0o0oo * o0O0OOO0Ooo . o00oooO0Oo + OOooo0O00o
    if 78 - 78: i11iIiiIii / OOOO00O0O - o0O0OOO0Ooo / IIiIiiIi + OOooo0O00o
def oOoooo0O0Oo ( _in , _out , dp = None ) :
 if dp :
  return o00ooO ( _in , _out , dp )
  if 89 - 89: Ii11II1iII1I1 * IIiIi1iI * IiiIIIiI + OOOO00O0O - o00oooO0Oo
 return IIiiIiII1Ii ( _in , _out )
 if 88 - 88: ooo0oo0o0oo * IiiIIIiI * OOO0O0O0ooooo
 if 64 - 64: IIiIiiIi % IIii1I * OOooo0O00o
def IIiiIiII1Ii ( _in , _out ) :
 try :
  o0iI11I1II = zipfile . ZipFile ( _in , 'r' )
  o0iI11I1II . extractall ( _out )
  if 40 - 40: IIii1I / IIiIi1iI % I11i1ii1 + ooo0oo0o0oo
 except Exception , ii1Ii1I1Ii11i :
  print str ( ii1Ii1I1Ii11i )
  return False
  if 35 - 35: i1IiiiI1iI
 return True
 if 90 - 90: IiiIIIiI % o0O0OOO0Ooo - IIii1I - IIii1I / i11iIiiIii % I11i1ii1
 if 37 - 37: OOooo0O00o - iiiii1I1I1I . o00oooO0Oo * o0O0OOO0Ooo - OOOO00O0O
def o00ooO ( _in , _out , dp ) :
 o0iI11I1II = zipfile . ZipFile ( _in , 'r' )
 II1I11Ii1 = float ( len ( o0iI11I1II . infolist ( ) ) )
 Ii = 0
 if 16 - 16: iiiii1I1I1I
 try :
  if 71 - 71: ii * ooo0oo0o0oo * OOooo0O00o
  for oOOo0II1I1iiIII in o0iI11I1II . infolist ( ) :
   Ii += 1
   oOOo0O00o = Ii / II1I11Ii1 * 100
   dp . update ( int ( oOOo0O00o ) )
   o0iI11I1II . extract ( oOOo0II1I1iiIII , _out )
   if 8 - 8: oOOo0
 except Exception , ii1Ii1I1Ii11i :
  print str ( ii1Ii1I1Ii11i )
  return False
  if 49 - 49: iiiii1I1I1I - o00oooO0Oo
 return True
 if 74 - 74: IIii1I * I11i1ii1 + IIiIi1iI / O00ooooo00 / ooo0oo0o0oo . Ii11II1iII1I1
 if 62 - 62: II1 * iiiii1I1I1I
def oOOOoo0O0oO ( ) :
 iIII1I111III = 'defaultskindependecycheck'
 if os . path . exists ( OOOO0OOoO0O0 ) :
  shutil . rmtree ( OOOO0OOoO0O0 )
  if 20 - 20: i1IiiiI1iI . ooo0oo0o0oo % IIiIiiIi * IIii1I
 if not os . path . exists ( OOOO0OOoO0O0 ) :
  os . makedirs ( OOOO0OOoO0O0 )
  if 98 - 98: iiiii1I1I1I % o0O0OOO0Ooo * II1
  if 51 - 51: IIii1I . IIiIi1iI / OOooo0O00o + i1IiiiI1iI
  if 33 - 33: i1Iii1i1I . ooo0oo0o0oo % OOOO00O0O + i1IiiiI1iI
 if O000oo0O != 'skin.confluence' :
  oO00O000oO0 = os . path . join ( iIii1 , O000oo0O , 'addon.xml' )
  O0OoOO0o = open ( oO00O000oO0 , mode = 'r' )
  ooooo0O0000oo = O0OoOO0o . read ( )
  O0OoOO0o . close ( )
  if 21 - 21: i1IiiiI1iI - iiiii1I1I1I
  II11I1 = re . compile ( '<requires[\s\S]*?\/requires' ) . findall ( ooooo0O0000oo )
  iIII1I111III = II11I1 [ 0 ] if ( len ( II11I1 ) > 0 ) else 'None'
  if 62 - 62: I11i1ii1 / O00ooooo00
 oo0oO = Oo0O0 ( 'http://totalxbmc.com/TI/AddonPortal/approved.php' )
 if 82 - 82: ooo0oo0o0oo % o00oooO0Oo / oOOo0 + IIiIi1iI / i1IiiiI1iI / IiiIIIiI
 oO . create ( 'Backing Up Add-ons' , '' , 'Please Wait...' )
 if 70 - 70: OOooo0O00o
 for oOOoO0o0oO in os . listdir ( iIii1 ) :
  if 93 - 93: ii * II1 + i1Iii1i1I
  if 33 - 33: OOO0O0O0ooooo * i1IiiiI1iI - IiiIIIiI % IiiIIIiI
  if not 'totalinstaller' in oOOoO0o0oO and not 'plugin.program.tbs' in oOOoO0o0oO and not 'packages' in oOOoO0o0oO and not 'repo.' in oOOoO0o0oO and not 'repository' in oOOoO0o0oO and os . path . isdir ( os . path . join ( iIii1 , oOOoO0o0oO ) ) :
   if 18 - 18: IiiIIIiI / Ii11II1iII1I1 * IiiIIIiI + IiiIIIiI * i11iIiiIii * I11i1ii1
   if 11 - 11: i1Iii1i1I / IIiIi1iI - ii * II1 + II1 . IIiIi1iI
   if oOOoO0o0oO in oo0oO and not oOOoO0o0oO in iIII1I111III and not 'script.skin' in oOOoO0o0oO and not 'script.common.plugin' in oOOoO0o0oO and not 'script.module' in oOOoO0o0oO and os . path . isdir ( os . path . join ( iIii1 , oOOoO0o0oO ) ) :
    if 26 - 26: o0O0OOO0Ooo % I11i1ii1
    if 76 - 76: ii * OOOO00O0O
    if not 'service.xbmc.versioncheck' in oOOoO0o0oO and not 'packages' in oOOoO0o0oO and os . path . isdir ( os . path . join ( iIii1 , oOOoO0o0oO ) ) :
     if 52 - 52: IIiIiiIi
     try :
      oO . update ( 0 , "Backing Up" , '[COLOR darkcyan]%s[/COLOR]' % oOOoO0o0oO , 'Please Wait...' )
      os . makedirs ( os . path . join ( OOOO0OOoO0O0 , oOOoO0o0oO ) )
      if 19 - 19: iiiii1I1I1I
      i11i = os . path . join ( OOOO0OOoO0O0 , oOOoO0o0oO , 'addon.xml' )
      o0oooOO00 = os . path . join ( OOOO0OOoO0O0 , oOOoO0o0oO , 'default.py' )
      iiIiii1IIIII = open ( os . path . join ( iIii1 , oOOoO0o0oO , 'addon.xml' ) , mode = 'r' )
      O000OOo00oo = iiIiii1IIIII . read ( )
      iiIiii1IIIII . close ( )
      if 67 - 67: o0O0OOO0Ooo / ii
      iiIiIIIiiI = re . compile ( ' name="(.+?)"' ) . findall ( O000OOo00oo )
      iiI1IIIi = re . compile ( 'provider-name="(.+?)"' ) . findall ( O000OOo00oo )
      II11IiIi11 = re . compile ( '<addon[\s\S]*?">' ) . findall ( O000OOo00oo )
      IIOOO0O00O0OOOO = re . compile ( '<description[\s\S]*?<\/description>' ) . findall ( O000OOo00oo )
      I1iiii1I = iiIiIIIiiI [ 0 ] if ( len ( iiIiIIIiiI ) > 0 ) else 'None'
      OOo0 = iiI1IIIi [ 0 ] if ( len ( iiI1IIIi ) > 0 ) else 'Anonymous'
      oO00ooooO0o = II11IiIi11 [ 0 ] if ( len ( II11IiIi11 ) > 0 ) else 'None'
      oo0o = IIOOO0O00O0OOOO [ 0 ] if ( len ( IIOOO0O00O0OOOO ) > 0 ) else 'None'
      if 51 - 51: o00oooO0Oo % iiiii1I1I1I
      OooOo = '<addon id="' + oOOoO0o0oO + '" name="' + I1iiii1I + '" version="0" provider-name="' + OOo0 + '">'
      i11III1111iIi = '<description>If you\'re seeing this message it means the add-on is still updating, please wait for the update process to complete.</description>'
      if 38 - 38: OOOO00O0O + o00oooO0Oo / IiiIIIiI % i1Iii1i1I - I11i1ii1
      if oO00ooooO0o != 'None' :
       iI11 = O000OOo00oo . replace ( oo0o , i11III1111iIi ) . replace ( oO00ooooO0o , OooOo )
       if 10 - 10: ooo0oo0o0oo / OOooo0O00o % II1 * o00oooO0Oo % I11i1ii1
      else :
       iI11 = O000OOo00oo . replace ( oo0o , i11III1111iIi )
       if 48 - 48: i1Iii1i1I / IiiIIIiI . IIii1I * IIiIi1iI * OOooo0O00o / O00ooooo00
      OOOOoOOo0O0 = open ( i11i , mode = 'w+' )
      OOOOoOOo0O0 . write ( str ( iI11 ) )
      OOOOoOOo0O0 . close ( )
      oOooo0 = open ( o0oooOO00 , mode = 'w+' )
      oOooo0 . write ( 'import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys\nAddonID="' + oOOoO0o0oO + '"\nAddonName="' + I1iiii1I + '"\ndialog=xbmcgui.Dialog()\nxbmc.executebuiltin("UpdateLocalAddons")\nxbmc.executebuiltin("UpdateAddonRepos")\nchoice=dialog.yesno(AddonName+" Add-on Requires Update","This add-on may still be in the process of the updating, would you like check the status of your add-on updates or try re-installing via the Total Installer backup method? We highly recommend checking for updates.",yeslabel="Install Option 2", nolabel="Check Updates")\nif choice==0: xbmc.executebuiltin(\'ActivateWindow(10040,"addons://outdated/",return)\')\nelse: xbmc.executebuiltin(\'ActivateWindow(10001,"plugin://plugin.program.tbs/?mode=grab_addons&url=%26redirect%26addonid%3d\'+AddonID+\'")\')\nxbmcplugin.endOfDirectory(int(sys.argv[1]))' )
      oOooo0 . close ( )
      if 58 - 58: iiiii1I1I1I . OOOO00O0O + IIiIi1iI
     except :
      pass
      if 66 - 66: OOOO00O0O / OOooo0O00o * II1 + II1 % o00oooO0Oo
      if 49 - 49: OOooo0O00o - i11iIiiIii . IiiIIIiI * o0O0OOO0Ooo % OOOO00O0O + O00ooooo00
   else :
    shutil . copytree ( os . path . join ( iIii1 , oOOoO0o0oO ) , os . path . join ( OOOO0OOoO0O0 , oOOoO0o0oO ) )
    if 71 - 71: i1IiiiI1iI
 oO . close ( )
 if 38 - 38: OOooo0O00o % IIiIi1iI + I11i1ii1 . i11iIiiIii
 oo0000ooooO0o = "Creating Backup"
 iI1i11 = "Archiving..."
 OoOOoooOO0O = ""
 ooo00Ooo = "Please Wait"
 if 93 - 93: i11iIiiIii - iiiii1I1I1I * I11i1ii1 * o00oooO0Oo % OOO0O0O0ooooo + II1
 Archive_Tree ( OOOO0OOoO0O0 , O0Oo000ooO00 , oo0000ooooO0o , iI1i11 , OoOOoooOO0O , ooo00Ooo , '' , '' )
 if 25 - 25: ii + o0O0OOO0Ooo / i1Iii1i1I . i1IiiiI1iI % OOO0O0O0ooooo * oOOo0
 try :
  shutil . rmtree ( OOOO0OOoO0O0 )
  if 84 - 84: i1Iii1i1I % o0O0OOO0Ooo + i11iIiiIii
 except :
  pass
  if 28 - 28: Ii11II1iII1I1 + oOOo0 * IIiIiiIi % OOooo0O00o . o00oooO0Oo % OOO0O0O0ooooo
  if 16 - 16: o00oooO0Oo - IIii1I / iiiii1I1I1I . ooo0oo0o0oo + IIii1I
def DLE ( command , repo_link , repo_id ) :
 i11OOoo = 'DLE'
 iIIiiiI = os . path . join ( o00OO00OoO , 'updates.zip' )
 if 60 - 60: iiiii1I1I1I . IiiIIIiI
 if command == 'delete' :
  shutil . rmtree ( xbmc . translatePath ( repo_link ) )
  if 34 - 34: iiiii1I1I1I % OOOO00O0O + i1Iii1i1I * IIii1I
 if command == 'addons' or command == 'ADDON_DATA' or command == 'media' or command == 'config' or command == 'playlists' :
  if 33 - 33: iiiii1I1I1I / i1Iii1i1I * IIiIiiIi / I11i1ii1 + Ii11II1iII1I1 / OOOO00O0O
  if (repo_id != 'repository.xbmc.org' and not os . path . exists ( os . path . join ( iIii1 , repo_id ) ) ) or repo_id == '':
   try :
    downloader . download ( repo_link , iIIiiiI )
   except : print"###failed dl"
   if 40 - 40: I11i1ii1
  if ( command == "addons" and not os . path . exists ( os . path . join ( iIii1 , repo_id ) ) ) or ( command == 'addons' and repo_id == '' ) or ( command == 'addons' and repo_id == 'repository.xbmc.org' ) :
   try :
    oOoooo0O0Oo ( iIIiiiI , iIii1 )
   except : print"###failed extr"
   if 60 - 60: I11i1ii1 % IIiIi1iI * oOOo0 % ooo0oo0o0oo
  if command == 'ADDON_DATA' :
   try :
    oOoooo0O0Oo ( iIIiiiI , i1iiIII111ii )
   except : pass
   if 70 - 70: oOOo0 % OOooo0O00o + IIiIiiIi / o0O0OOO0Ooo % OOO0O0O0ooooo
  if command == 'media' :
   try :
    oOoooo0O0Oo ( iIIiiiI , ii11iIi1I )
   except : pass
   if 100 - 100: i1IiiiI1iI + IIiIiiIi * i1IiiiI1iI
  if command == 'config' :
   try :
    oOoooo0O0Oo ( iIIiiiI , oo0OooOOo0 )
   except : pass
   if 80 - 80: i1IiiiI1iI * OOO0O0O0ooooo - o0O0OOO0Ooo
  if command == 'playlists' :
   try :
    oOoooo0O0Oo ( iIIiiiI , i1iIIi1 )
   except : pass
   if 66 - 66: i11iIiiIii - IIiIiiIi * Ii11II1iII1I1
 if os . path . exists ( iIIiiiI ) :
  os . remove ( iIIiiiI )
  if 76 - 76: i11iIiiIii + i1IiiiI1iI / I11i1ii1 - oOOo0 - o0O0OOO0Ooo + I11i1ii1
  if 51 - 51: IIii1I . i1Iii1i1I + IIii1I
  if 95 - 95: iiiii1I1I1I
  if 46 - 46: IIiIi1iI + oOOo0
  if 70 - 70: OOOO00O0O / IIii1I
def KLL ( ) :
 IiIiII1 = 'KLL'
 if xbmc . getCondVisibility ( 'system.platform.windows' ) :
  try :
   os . system ( '@ECHO off' )
   os . system ( 'TASKKILL /im Kodi.exe /f' )
  except : pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'tskill Kodi.exe' )
  except : pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'tskill XBMC.exe' )
  except : pass
  try :
   os . system ( '@ECHO off' )
   os . system ( 'TASKKILL /im XBMC.exe /f' )
  except : pass
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  try : os . system ( 'killall -9 XBMC' )
  except : pass
  try : os . system ( 'killall -9 Kodi' )
  except : pass
 else :
  if 21 - 21: OOO0O0O0ooooo % ii . iiiii1I1I1I / ooo0oo0o0oo + ii
  try : os . system ( 'killall XBMC' )
  except : pass
  try : os . system ( 'killall Kodi' )
  except : pass
  try : os . system ( 'killall -9 xbmc.bin' )
  except : pass
  try : os . system ( 'killall -9 kodi.bin' )
  except : pass
  if 53 - 53: OOooo0O00o - iiiii1I1I1I - OOooo0O00o * OOOO00O0O
  try : os . system ( 'killall AppleTV' )
  except : pass
  try : os . system ( 'sudo initctl stop kodi' )
  except : pass
  try : os . system ( 'sudo initctl stop xbmc' )
  except : pass
  if 71 - 71: OOO0O0O0ooooo - IIii1I
  try : os . system ( 'adb shell am force-stop org.xbmc.kodi' )
  except : pass
  try : os . system ( 'adb shell am force-stop org.kodi' )
  except : pass
  try : os . system ( 'adb shell am force-stop org.xbmc.xbmc' )
  except : pass
  try : os . system ( 'adb shell am force-stop org.xbmc' )
  except : pass
  try : os . system ( 'adb shell kill org.xbmc.kodi' )
  except : pass
  try : os . system ( 'adb shell kill org.kodi' )
  except : pass
  try : os . system ( 'adb shell kill org.xbmc.xbmc' )
  except : pass
  try : os . system ( 'adb shell kill org.xbmc' )
  except : pass
  try : os . system ( 'Process.killProcess(android.os.Process.org.xbmc,kodi());' )
  except : pass
  try : os . system ( 'Process.killProcess(android.os.Process.org.kodi());' )
  except : pass
  try : os . system ( 'Process.killProcess(android.os.Process.org.xbmc.xbmc());' )
  except : pass
  try : os . system ( 'Process.killProcess(android.os.Process.org.xbmc());' )
  except : pass
  try : xbmc . executebuiltin ( 'StartAndroidActivity(android.provider.Settings)' )
  except : pass
  if 12 - 12: IIiIiiIi / i1IiiiI1iI
  if 42 - 42: Ii11II1iII1I1
def Oo0O0 ( url ) :
 II1IIiiIiI = urllib2 . Request ( url )
 II1IIiiIiI . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 i1II1I1Iii1 = urllib2 . urlopen ( II1IIiiIiI )
 OOO = i1II1I1Iii1 . read ( )
 i1II1I1Iii1 . close ( )
 return OOO
 if 30 - 30: II1 - IIiIi1iI
 if 75 - 75: IIii1I - o0O0OOO0Ooo . Ii11II1iII1I1 % i11iIiiIii % o00oooO0Oo
def oo0OOo0 ( url ) :
 II1IIiiIiI = urllib2 . Request ( url )
 II1IIiiIiI . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 i1II1I1Iii1 = urllib2 . urlopen ( II1IIiiIiI )
 OOO = i1II1I1Iii1 . read ( )
 i1II1I1Iii1 . close ( )
 return OOO . replace ( '\r' , '\\r' ) . replace ( '\n' , '\\n' ) . replace ( '\t' , '\\t' )
 if 55 - 55: OOOO00O0O . ooo0oo0o0oo % oOOo0 * OOOO00O0O + i1Iii1i1I + o0O0OOO0Ooo
 if 24 - 24: Ii11II1iII1I1 - OOooo0O00o % IIii1I . O00ooooo00 / OOO0O0O0ooooo
def OEB ( ) :
 I111i1i1111 = 'OEB'
 import tarfile
 if 49 - 49: oOOo0 / OOooo0O00o + OOO0O0O0ooooo * i1IiiiI1iI
 if not os . path . exists ( IIIii1II1II ) :
  os . makedirs ( IIIii1II1II )
  if 28 - 28: i1Iii1i1I + i11iIiiIii / o00oooO0Oo % IIiIi1iI % Ii11II1iII1I1 - OOO0O0O0ooooo
 ooo0OOO = tarfile . open ( os . path . join ( IIIii1II1II , iii1Ii1Ii1 ( ) + '.tar' ) , 'w' )
 if 21 - 21: OOooo0O00o . IiiIIIiI . IIiIiiIi / Ii11II1iII1I1 / IiiIIIiI
 for i1iI1 in Oo0OoO00oOO0o :
  ooo0OOO . add ( i1iI1 )
  if 1 - 1: O00ooooo00 . i11iIiiIii % IIiIiiIi
 ooo0OOO . close ( )
 if 82 - 82: IIii1I + Ii11II1iII1I1 . IIii1I % ii / o0O0OOO0Ooo . o0O0OOO0Ooo
 if 14 - 14: i1IiiiI1iI . IIiIiiIi . o00oooO0Oo + II1 - IIiIiiIi + ii
def iII1iiiiIII ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 OOoOO0oo00Oo = xbmc . translatePath ( os . path . join ( iIii1 , addon_id ) )
 forum = str ( forum )
 if 50 - 50: i1Iii1i1I - IiiIIIiI * ii . I11i1ii1
 if not os . path . exists ( OOoOO0oo00Oo ) :
  I11iiiii1II = 1
  if 51 - 51: OOO0O0O0ooooo % OOooo0O00o - ooo0oo0o0oo
 else :
  I11iiiii1II = 0
  if 31 - 31: OOOO00O0O / Ii11II1iII1I1 - OOOO00O0O - IIiIiiIi
 repo_id = str ( repo_id )
 I1iiIIIi11 = xbmc . translatePath ( os . path . join ( iIii1 , repo_id ) )
 if 12 - 12: II1 % i1IiiiI1iI * o00oooO0Oo % IIii1I / o0O0OOO0Ooo
 if os . path . exists ( OOoOO0oo00Oo ) :
  Ii1ii1IiIII = 1
  ooO0o = dialog . yesno ( 'Add-on Already Installed' , 'This add-on has already been detected on your system. Would you like to remove the old version and re-install? There should be no need for this unless you\'ve manually opened up the add-on code and edited in a text editor.' )
  if 51 - 51: ii
  if ooO0o == 1 :
   Remove_Addons ( OOoOO0oo00Oo )
   I11iiiii1II = 1
 else :
  Ii1ii1IiIII = 0
  if 25 - 25: II1 + ii * I11i1ii1
 if I11iiiii1II == 1 :
  if 92 - 92: iiiii1I1I1I + o00oooO0Oo + OOO0O0O0ooooo / i1IiiiI1iI + IiiIIIiI
  if ( repo_id != 'repository.xbmc.org' ) and not ( os . path . exists ( I1iiIIIi11 ) ) and ( repo_id != '' ) and ( 'superrepo' not in repo_id ) :
   Install_Repo ( repo_id )
   if 18 - 18: i1Iii1i1I * IIiIi1iI . OOOO00O0O / I11i1ii1 / i11iIiiIii
  if not os . path . exists ( OOoOO0oo00Oo ) :
   os . makedirs ( OOoOO0oo00Oo )
   if 21 - 21: OOooo0O00o / I11i1ii1 + o0O0OOO0Ooo + II1
  i11i = os . path . join ( iIii1 , addon_id , 'addon.xml' )
  o0oooOO00 = os . path . join ( iIii1 , addon_id , 'default.py' )
  if 91 - 91: i11iIiiIii / O00ooooo00 + OOOO00O0O + i1Iii1i1I * i11iIiiIii
  shutil . copyfile ( iiI1IiI , i11i )
  if 66 - 66: IIii1I % O00ooooo00 - OOO0O0O0ooooo + o00oooO0Oo * IiiIIIiI . ii
  iiIiii1IIIII = open ( os . path . join ( i11i ) , mode = 'r' )
  O000OOo00oo = iiIiii1IIIII . read ( )
  iiIiii1IIIII . close ( )
  if 52 - 52: i1Iii1i1I + OOO0O0O0ooooo . OOOO00O0O . I11i1ii1 . oOOo0
  if 97 - 97: iiiii1I1I1I / OOOO00O0O
  Oooo0 = re . compile ( 'testid[\s\S]*?' ) . findall ( O000OOo00oo )
  oOO = Oooo0 [ 0 ] if ( len ( Oooo0 ) > 0 ) else 'None'
  iiIiIIIiiI = re . compile ( 'testname[\s\S]*?' ) . findall ( O000OOo00oo )
  I1iiii1I = iiIiIIIiiI [ 0 ] if ( len ( iiIiIIIiiI ) > 0 ) else 'None'
  iiI1IIIi = re . compile ( 'testprovider[\s\S]*?' ) . findall ( O000OOo00oo )
  Oooo = iiI1IIIi [ 0 ] if ( len ( iiI1IIIi ) > 0 ) else 'None'
  I1i1iiiII1i = re . compile ( 'testprovides[\s\S]*?' ) . findall ( O000OOo00oo )
  oO0oO0 = I1i1iiiII1i [ 0 ] if ( len ( I1i1iiiII1i ) > 0 ) else 'None'
  iI11 = O000OOo00oo . replace ( oOO , addon_id ) . replace ( I1iiii1I , name ) . replace ( Oooo , provider_name ) . replace ( oO0oO0 , contenttypes )
  if 14 - 14: OOOO00O0O
  OOOOoOOo0O0 = open ( i11i , mode = 'w+' )
  OOOOoOOo0O0 . write ( str ( iI11 ) )
  OOOOoOOo0O0 . close ( )
  if 99 - 99: OOOO00O0O
  oOooo0 = open ( o0oooOO00 , mode = 'w' )
  oOooo0 . write ( 'import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys\nAddonID="' + addon_id + '"\nAddonName="' + name + '"\ndialog=xbmcgui.Dialog()\nxbmc.executebuiltin("UpdateLocalAddons")\nxbmc.executebuiltin("UpdateAddonRepos")\nchoice=dialog.yesno(AddonName+" Add-on Requires Update","This add-on may still be in the process of the updating, would you like check the status of your add-on updates or try re-installing via the Total Installer backup method? We highly recommend checking for updates.",yeslabel="Install Option 2", nolabel="Check Updates")\nif choice==0: xbmc.executebuiltin(\'ActivateWindow(10040,"addons://outdated/",return)\')\nelse: xbmc.executebuiltin(\'ActivateWindow(10001,"plugin://plugin.program.tbs/?mode=grab_addons&url=%26redirect%26addonid%3d\'+AddonID+\'")\')\nxbmcplugin.endOfDirectory(int(sys.argv[1]))' )
  oOooo0 . close ( )
  if 38 - 38: I11i1ii1 - OOOO00O0O / OOO0O0O0ooooo . IiiIIIiI
  xbmc . sleep ( 1000 )
  if 45 - 45: IiiIIIiI
  if os . path . exists ( OOoOO0oo00Oo ) and Ii1ii1IiIII == 0 :
   oOIIi1iiii1iI = 'http://totalxbmc.com/totalrevolution/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   Oo0O0 ( oOIIi1iiii1iI )
   if 25 - 25: I11i1ii1 + OOO0O0O0ooooo
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  dialog . ok ( name + " Install Complete" , '[COLOR=dodgerblue]' + name + '[/COLOR] has now been installed, please allow a few moments for Kodi to update the add-on and it\'s dependencies.' )
  if 28 - 28: II1
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 89 - 89: OOOO00O0O - i1Iii1i1I % Ii11II1iII1I1 % i1IiiiI1iI
 if 49 - 49: Ii11II1iII1I1 - iiiii1I1I1I / ii / OOO0O0O0ooooo % i1IiiiI1iI * o0O0OOO0Ooo
def OOo ( ) :
 O0II11iI111i1 = xbmc . translatePath ( 'special://home/userdata/Database/Textures13.db' )
 try :
  Oo00OoOo = database . connect ( O0II11iI111i1 )
  ii1ii111i11111I1I = Oo00OoOo . cursor ( )
  ii1ii111i11111I1I . execute ( "DROP TABLE IF EXISTS path" )
  ii1ii111i11111I1I . execute ( "VACUUM" )
  Oo00OoOo . commit ( )
  ii1ii111i11111I1I . execute ( "DROP TABLE IF EXISTS sizes" )
  ii1ii111i11111I1I . execute ( "VACUUM" )
  Oo00OoOo . commit ( )
  ii1ii111i11111I1I . execute ( "DROP TABLE IF EXISTS texture" )
  ii1ii111i11111I1I . execute ( "VACUUM" )
  Oo00OoOo . commit ( )
  ii1ii111i11111I1I . execute ( """CREATE TABLE path (id integer, url text, type text, texture text, primary key(id))""" )
  Oo00OoOo . commit ( )
  ii1ii111i11111I1I . execute ( """CREATE TABLE sizes (idtexture integer,size integer, width integer, height integer, usecount integer, lastusetime text)""" )
  Oo00OoOo . commit ( )
  ii1ii111i11111I1I . execute ( """CREATE TABLE texture (id integer, url text, cachedurl text, imagehash text, lasthashcheck text, PRIMARY KEY(id))""" )
  Oo00OoOo . commit ( )
 except :
  pass
  if 11 - 11: II1 . IiiIIIiI
  if 80 - 80: II1 - IIiIiiIi * o0O0OOO0Ooo * I11i1ii1 / iiiii1I1I1I / IIiIiiIi
def RMT ( ) :
 oo0o0O0Oooooo = 'RMT'
 OOo ( )
 i11IIIiI1I ( )
 if 69 - 69: OOO0O0O0ooooo
 if 85 - 85: i1Iii1i1I / OOO0O0O0ooooo
def SF ( command , SF_folder , SF_link ) :
 ooo = 'SF'
 if 70 - 70: ooo0oo0o0oo % O00ooooo00 / I11i1ii1 . II1 * Ii11II1iII1I1
 iIiiiii1i = xbmc . translatePath ( os . path . join ( i1iiIII111ii , 'plugin.program.super.favourites' , 'Super Favourites' , SF_folder ) )
 iiIi1IIiI = os . path . join ( iIiiiii1i , 'favourites.xml' )
 if 23 - 23: o0O0OOO0Ooo . IIiIiiIi
 if command == 'add' :
  if 9 - 9: i1Iii1i1I - I11i1ii1 - OOOO00O0O
  if not os . path . exists ( iIiiiii1i ) :
   os . makedirs ( iIiiiii1i )
   O00OOOoOoo0O = open ( iiIi1IIiI , mode = 'w+' )
   O00OOOoOoo0O . write ( '<favourites>\n</favourites>' )
   O00OOOoOoo0O . close ( )
   if 82 - 82: ii - ii + IIiIi1iI
   if 8 - 8: i1IiiiI1iI % OOOO00O0O * OOooo0O00o % o0O0OOO0Ooo . i1Iii1i1I / i1Iii1i1I
  o0O0O0o = open ( iiIi1IIiI , mode = 'r' )
  OO = o0O0O0o . read ( )
  o0O0O0o . close ( )
  if 40 - 40: IIiIi1iI / ii
  OOOoO000 = re . compile ( '<favourite name="[\s\S]*?\/favourites>' ) . findall ( OO )
  oOOOO = OOOoO000 [ 0 ] if ( len ( OOOoO000 ) > 0 ) else '\n</favourites>'
  if 49 - 49: ooo0oo0o0oo . OOooo0O00o . i11iIiiIii % ii
  if 34 - 34: IiiIIIiI % ii
  O00OOOoOoo0O = open ( I1IIIii , mode = 'r' )
  IiI1i = O00OOOoOoo0O . read ( )
  O00OOOoOoo0O . close ( )
  if 87 - 87: i1Iii1i1I
  if 45 - 45: oOOo0 / II1 - OOOO00O0O / o0O0OOO0Ooo % ii
  if not IiI1i in OO :
   O00OOOoOoo0O = open ( iiIi1IIiI , mode = 'w+' )
   if oOOOO == '\n</favourites>' :
    OoO = O00OOOoOoo0O . write ( '<favourites>\n\t' + IiI1i + oOOOO )
   else :
    OoO = O00OOOoOoo0O . write ( '<favourites>\n\t' + IiI1i + '\n\t' + oOOOO )
   O00OOOoOoo0O . close ( )
   if 14 - 14: i11iIiiIii * OOOO00O0O / O00ooooo00 * IiiIIIiI + ooo0oo0o0oo % OOOO00O0O
 if command == 'delete' :
  if 51 - 51: i11iIiiIii . I11i1ii1 + ii / I11i1ii1
  if 35 - 35: ii
  try :
   o0O0O0o = open ( iiIi1IIiI , mode = 'r' )
   OO = o0O0O0o . read ( )
   o0O0O0o . close ( )
   if 75 - 75: Ii11II1iII1I1 / I11i1ii1 . ii * IIiIiiIi - ooo0oo0o0oo
   if 41 - 41: o0O0OOO0Ooo
   O00OOOoOoo0O = open ( I1IIIii , mode = 'r' )
   IiI1i = O00OOOoOoo0O . read ( )
   O00OOOoOoo0O . close ( )
   if 77 - 77: IiiIIIiI
   if 65 - 65: ooo0oo0o0oo . iiiii1I1I1I % OOooo0O00o * oOOo0
   O00OOOoOoo0O = open ( iiIi1IIiI , mode = 'w+' )
   OoO = O00OOOoOoo0O . write ( OO . replace ( '\n\t' + IiI1i , '' ) )
   O00OOOoOoo0O . close ( )
  except :
   pass
   if 38 - 38: IIiIi1iI / OOOO00O0O % Ii11II1iII1I1
   if 11 - 11: OOOO00O0O - OOooo0O00o + ooo0oo0o0oo - IIii1I
 if command == 'delfolder' :
  if 7 - 7: ii - o00oooO0Oo / ooo0oo0o0oo * o0O0OOO0Ooo . OOOO00O0O * OOOO00O0O
  try :
   shutil . rmtree ( iIiiiii1i )
  except :
   pass
   if 61 - 61: o00oooO0Oo % i1Iii1i1I - oOOo0 / Ii11II1iII1I1
   if 4 - 4: II1 - O00ooooo00 % o0O0OOO0Ooo - IIiIiiIi * i1IiiiI1iI
def TXT ( heading , anounce ) :
 oooo0O0O0o0 = 'TXT'
 class Ooo0oo ( ) :
  WINDOW = 10147
  CONTROL_LABEL = 1
  CONTROL_TEXTBOX = 5
  def __init__ ( self , * args , ** kwargs ) :
   xbmc . executebuiltin ( "ActivateWindow(%d)" % ( self . WINDOW , ) )
   self . win = xbmcgui . Window ( self . WINDOW )
   xbmc . sleep ( 500 )
   self . setControls ( )
  def setControls ( self ) :
   self . win . getControl ( self . CONTROL_LABEL ) . setLabel ( heading )
   try : IIi11IIiIii1 = open ( anounce ) ; I1iIII1 = IIi11IIiIii1 . read ( )
   except : I1iIII1 = anounce
   self . win . getControl ( self . CONTROL_TEXTBOX ) . setText ( str ( I1iIII1 ) )
   return
 Ooo0oo ( )
 while xbmc . getCondVisibility ( 'Window.IsVisible(textviewer)' ) :
  xbmc . sleep ( 500 )
  if 39 - 39: II1
  if 38 - 38: iiiii1I1I1I
def oOo0OoOOo0 ( name , contenttypes , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 I1iiIIIi11 = xbmc . translatePath ( os . path . join ( iIii1 , repo_id ) )
 OOoOO0oo00Oo = xbmc . translatePath ( os . path . join ( iIii1 , addon_id ) )
 if 30 - 30: I11i1ii1 % iiiii1I1I1I
 if os . path . exists ( OOoOO0oo00Oo ) :
  if 89 - 89: IiiIIIiI + II1 + IiiIIIiI * O00ooooo00 + IIii1I % o00oooO0Oo
  ooO0o = dialog . yesno ( 'Add-on Already Installed' , 'This add-on has already been detected on your system. Would you like to remove the old version and re-install? There should be no need for this unless you\'ve manually opened up the add-on code and edited in a text editor.' )
  if 59 - 59: IIiIiiIi + i11iIiiIii
  if ooO0o == 1 :
   Remove_Addons ( OOoOO0oo00Oo )
   if 88 - 88: i11iIiiIii - i1Iii1i1I
 if os . path . exists ( I1iiIIIi11 ) :
  if 67 - 67: IIiIiiIi . Ii11II1iII1I1 + IIiIi1iI - II1
  if os . path . exists ( OOoOO0oo00Oo ) :
   Ii1ii1IiIII = 1
   if 70 - 70: IIiIiiIi / ooo0oo0o0oo - IIii1I - OOOO00O0O
  else :
   Ii1ii1IiIII = 0
   if 11 - 11: IIii1I . II1 . ooo0oo0o0oo / O00ooooo00 - o00oooO0Oo
  ooO0o = dialog . yesno ( 'WARNING!' , '[COLOR=orange]This Add-on may be unlawful in your region.[/COLOR][CR]The repository required for installation of this add-on has been detected on your system. Would you like to continue to the Kodi addon browser to install?' )
  if 30 - 30: IIiIi1iI
  if ooO0o == 1 :
   if 21 - 21: i11iIiiIii / IiiIIIiI % IIiIiiIi * OOO0O0O0ooooo . o00oooO0Oo - IIii1I
   if 'video' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.video/?",return)' )
    if 26 - 26: ooo0oo0o0oo * IIiIi1iI
   elif 'executable' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.executable/?",return)' )
    if 10 - 10: ooo0oo0o0oo . OOOO00O0O
   elif 'audio' in contenttypes :
    xbmc . executebuiltin ( 'ActivateWindow(10040,"addons://' + repo_id + '/xbmc.addon.audio/?",return)' )
    if 32 - 32: o0O0OOO0Ooo . ii . II1 - oOOo0 + OOooo0O00o
  xbmc . sleep ( 2000 )
  if 88 - 88: OOOO00O0O
  if os . path . exists ( OOoOO0oo00Oo ) and Ii1ii1IiIII == 0 :
   oOIIi1iiii1iI = 'http://totalxbmc.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   Oo0O0 ( oOIIi1iiii1iI )
   if 19 - 19: ooo0oo0o0oo * ii + o0O0OOO0Ooo
 else :
  dialog . ok ( 'WARNING!' , '[COLOR=orange]This add-on may possibly be unlawful in your region.[/COLOR][CR]If you\'ve investigated the legality of it and are happy to install then you must have the following repository installed: [COLOR=dodgerblue]' + repo_id + '[/COLOR]' )
  if 65 - 65: IIiIiiIi . IiiIIIiI . oOOo0 . OOOO00O0O - IIiIiiIi
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 19 - 19: i11iIiiIii + OOOO00O0O % i1Iii1i1I
 if 14 - 14: oOOo0 . ooo0oo0o0oo . o00oooO0Oo / o0O0OOO0Ooo % I11i1ii1 - i1Iii1i1I
def iii1Ii1Ii1 ( ) :
 o0oOoO0O = time . time ( )
 OoOo000oOo0oo = time . localtime ( o0oOoO0O )
 return time . strftime ( '%Y%m%d%H%M%S' , OoOo000oOo0oo )
 if 65 - 65: IIiIi1iI / oOOo0 % ii
def iIiIIii ( ) :
 xbmc . executebuiltin ( 'UpdateLocalAddons' )
 xbmc . executebuiltin ( 'UpdateAddonRepos' )
 if 61 - 61: i1IiiiI1iI / IIiIiiIi / Ii11II1iII1I1 * OOO0O0O0ooooo
 if 23 - 23: OOooo0O00o - IIiIiiIi + o00oooO0Oo
def i11IIIiI1I ( ) :
 II11 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
 if os . path . exists ( II11 ) == True :
  for Iiii11iIi1 , i1iI11I1II1 , ii11II1i in os . walk ( II11 ) :
   OOOO000o0 = 0
   OOOO000o0 += len ( ii11II1i )
   if OOOO000o0 > 0 :
    for IIi11IIiIii1 in ii11II1i :
     try :
      os . unlink ( os . path . join ( Iiii11iIi1 , IIi11IIiIii1 ) )
     except :
      pass
    for oO0o000OoOoO0 in i1iI11I1II1 :
     try :
      shutil . rmtree ( os . path . join ( Iiii11iIi1 , oO0o000OoOoO0 ) )
     except :
      pass
 OO0ooOOO0O00o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
 if os . path . exists ( OO0ooOOO0O00o ) == True :
  for Iiii11iIi1 , i1iI11I1II1 , ii11II1i in os . walk ( OO0ooOOO0O00o ) :
   OOOO000o0 = 0
   OOOO000o0 += len ( ii11II1i )
   if OOOO000o0 > 0 :
    for IIi11IIiIii1 in ii11II1i :
     try :
      os . unlink ( os . path . join ( Iiii11iIi1 , IIi11IIiIii1 ) )
     except :
      pass
    for oO0o000OoOoO0 in i1iI11I1II1 :
     try :
      shutil . rmtree ( os . path . join ( Iiii11iIi1 , oO0o000OoOoO0 ) )
     except :
      pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  Ooo0o0oo = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  for Iiii11iIi1 , i1iI11I1II1 , ii11II1i in os . walk ( Ooo0o0oo ) :
   OOOO000o0 = 0
   OOOO000o0 += len ( ii11II1i )
   if OOOO000o0 > 0 :
    for IIi11IIiIii1 in ii11II1i :
     os . unlink ( os . path . join ( Iiii11iIi1 , IIi11IIiIii1 ) )
    for oO0o000OoOoO0 in i1iI11I1II1 :
     shutil . rmtree ( os . path . join ( Iiii11iIi1 , oO0o000OoOoO0 ) )
  Ii1i1i1111 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  for Iiii11iIi1 , i1iI11I1II1 , ii11II1i in os . walk ( Ii1i1i1111 ) :
   OOOO000o0 = 0
   OOOO000o0 += len ( ii11II1i )
   if OOOO000o0 > 0 :
    for IIi11IIiIii1 in ii11II1i :
     os . unlink ( os . path . join ( Iiii11iIi1 , IIi11IIiIii1 ) )
    for oO0o000OoOoO0 in i1iI11I1II1 :
     shutil . rmtree ( os . path . join ( Iiii11iIi1 , oO0o000OoOoO0 ) )
     if 57 - 57: o0O0OOO0Ooo % ooo0oo0o0oo
 O00oOo = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.module.simple.downloader' ) , '' )
 if os . path . exists ( O00oOo ) == True :
  for Iiii11iIi1 , i1iI11I1II1 , ii11II1i in os . walk ( O00oOo ) :
   OOOO000o0 = 0
   OOOO000o0 += len ( ii11II1i )
   if OOOO000o0 > 0 :
    for IIi11IIiIii1 in ii11II1i :
     os . unlink ( os . path . join ( Iiii11iIi1 , IIi11IIiIii1 ) )
    for oO0o000OoOoO0 in i1iI11I1II1 :
     shutil . rmtree ( os . path . join ( Iiii11iIi1 , oO0o000OoOoO0 ) )
     if 26 - 26: ii % IiiIIIiI % OOooo0O00o % o0O0OOO0Ooo
 O0oo0ooOOOO = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.image.music.slideshow/cache' ) , '' )
 if os . path . exists ( O0oo0ooOOOO ) == True :
  for Iiii11iIi1 , i1iI11I1II1 , ii11II1i in os . walk ( O0oo0ooOOOO ) :
   OOOO000o0 = 0
   OOOO000o0 += len ( ii11II1i )
   if OOOO000o0 > 0 :
    for IIi11IIiIii1 in ii11II1i :
     os . unlink ( os . path . join ( Iiii11iIi1 , IIi11IIiIii1 ) )
    for oO0o000OoOoO0 in i1iI11I1II1 :
     shutil . rmtree ( os . path . join ( Iiii11iIi1 , oO0o000OoOoO0 ) )
     if 14 - 14: iiiii1I1I1I / II1 % iiiii1I1I1I . OOO0O0O0ooooo
 OOOO0oooo = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache' ) , '' )
 if os . path . exists ( OOOO0oooo ) == True :
  for Iiii11iIi1 , i1iI11I1II1 , ii11II1i in os . walk ( OOOO0oooo ) :
   OOOO000o0 = 0
   OOOO000o0 += len ( ii11II1i )
   if OOOO000o0 > 0 :
    for IIi11IIiIii1 in ii11II1i :
     os . unlink ( os . path . join ( Iiii11iIi1 , IIi11IIiIii1 ) )
    for oO0o000OoOoO0 in i1iI11I1II1 :
     shutil . rmtree ( os . path . join ( Iiii11iIi1 , oO0o000OoOoO0 ) )
     if 51 - 51: OOO0O0O0ooooo - O00ooooo00 / iiiii1I1I1I
 iI111i1I1II = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.itv/Images' ) , '' )
 if os . path . exists ( iI111i1I1II ) == True :
  for Iiii11iIi1 , i1iI11I1II1 , ii11II1i in os . walk ( iI111i1I1II ) :
   OOOO000o0 = 0
   OOOO000o0 += len ( ii11II1i )
   if OOOO000o0 > 0 :
    for IIi11IIiIii1 in ii11II1i :
     os . unlink ( os . path . join ( Iiii11iIi1 , IIi11IIiIii1 ) )
    for oO0o000OoOoO0 in i1iI11I1II1 :
     shutil . rmtree ( os . path . join ( Iiii11iIi1 , oO0o000OoOoO0 ) )
     if 96 - 96: IiiIIIiI / Ii11II1iII1I1 * ooo0oo0o0oo - OOOO00O0O * Ii11II1iII1I1
 o0Ii1Iii111IiI1 = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/script.navi-x/cache' ) , '' )
 if os . path . exists ( o0Ii1Iii111IiI1 ) == True :
  for Iiii11iIi1 , i1iI11I1II1 , ii11II1i in os . walk ( o0Ii1Iii111IiI1 ) :
   OOOO000o0 = 0
   OOOO000o0 += len ( ii11II1i )
   if OOOO000o0 > 0 :
    for IIi11IIiIii1 in ii11II1i :
     os . unlink ( os . path . join ( Iiii11iIi1 , IIi11IIiIii1 ) )
    for oO0o000OoOoO0 in i1iI11I1II1 :
     shutil . rmtree ( os . path . join ( Iiii11iIi1 , oO0o000OoOoO0 ) )
     if 98 - 98: IiiIIIiI - II1 % iiiii1I1I1I + OOO0O0O0ooooo . o0O0OOO0Ooo
 OoOO = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.phstreams/Cache' ) , '' )
 if os . path . exists ( OoOO ) == True :
  for Iiii11iIi1 , i1iI11I1II1 , ii11II1i in os . walk ( OoOO ) :
   OOOO000o0 = 0
   OOOO000o0 += len ( ii11II1i )
   if OOOO000o0 > 0 :
    for IIi11IIiIii1 in ii11II1i :
     os . unlink ( os . path . join ( Iiii11iIi1 , IIi11IIiIii1 ) )
    for oO0o000OoOoO0 in i1iI11I1II1 :
     shutil . rmtree ( os . path . join ( Iiii11iIi1 , oO0o000OoOoO0 ) )
     if 44 - 44: IIiIiiIi
 O0O0o0o0o = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.audio.ramfm/cache' ) , '' )
 if os . path . exists ( O0O0o0o0o ) == True :
  for Iiii11iIi1 , i1iI11I1II1 , ii11II1i in os . walk ( O0O0o0o0o ) :
   OOOO000o0 = 0
   OOOO000o0 += len ( ii11II1i )
   if OOOO000o0 > 0 :
    for IIi11IIiIii1 in ii11II1i :
     os . unlink ( os . path . join ( Iiii11iIi1 , IIi11IIiIii1 ) )
    for oO0o000OoOoO0 in i1iI11I1II1 :
     shutil . rmtree ( os . path . join ( Iiii11iIi1 , oO0o000OoOoO0 ) )
     if 9 - 9: Ii11II1iII1I1 + IIiIi1iI - IIii1I - o0O0OOO0Ooo + i1IiiiI1iI
 o000O0OOoo = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.whatthefurk/cache' ) , '' )
 if os . path . exists ( o000O0OOoo ) == True :
  for Iiii11iIi1 , i1iI11I1II1 , ii11II1i in os . walk ( o000O0OOoo ) :
   OOOO000o0 = 0
   OOOO000o0 += len ( ii11II1i )
   if OOOO000o0 > 0 :
    for IIi11IIiIii1 in ii11II1i :
     os . unlink ( os . path . join ( Iiii11iIi1 , IIi11IIiIii1 ) )
    for oO0o000OoOoO0 in i1iI11I1II1 :
     shutil . rmtree ( os . path . join ( Iiii11iIi1 , oO0o000OoOoO0 ) )
     if 60 - 60: iiiii1I1I1I * IiiIIIiI % oOOo0 + OOooo0O00o
 try :
  o0oo = os . path . join ( xbmc . translatePath ( 'special://profile/addon_data/plugin.video.genesis' ) , 'cache.db' )
  Oo00OoOo = database . connect ( o0oo )
  ii1ii111i11111I1I = Oo00OoOo . cursor ( )
  ii1ii111i11111I1I . execute ( "DROP TABLE IF EXISTS rel_list" )
  ii1ii111i11111I1I . execute ( "VACUUM" )
  Oo00OoOo . commit ( )
  ii1ii111i11111I1I . execute ( "DROP TABLE IF EXISTS rel_lib" )
  ii1ii111i11111I1I . execute ( "VACUUM" )
  Oo00OoOo . commit ( )
 except :
  pass
  if 80 - 80: IiiIIIiI * IIiIi1iI * ooo0oo0o0oo - OOO0O0O0ooooo . IIiIi1iI % iiiii1I1I1I
  if 13 - 13: OOooo0O00o . iiiii1I1I1I * OOooo0O00o + iiiii1I1I1I
def OoOooo ( ) :
 oo00OOoOoO00 = xbmc . getInfoLabel ( "System.BuildVersion" )
 I1iii = float ( oo00OOoOoO00 [ : 4 ] )
 if I1iii < 14 :
  oOO0OO0O = os . path . join ( OOOOi11i1 , 'xbmc.log' )
 else :
  oOO0OO0O = os . path . join ( OOOOi11i1 , 'kodi.log' )
  if 78 - 78: o0O0OOO0Ooo / ooo0oo0o0oo % IIiIi1iI
 O00OOOoOoo0O = open ( oOO0OO0O , mode = 'r' )
 O000OOo00oo = O00OOOoOoo0O . read ( )
 O00OOOoOoo0O . close ( )
 if 52 - 52: IIiIiiIi - OOOO00O0O * OOooo0O00o
 if 'OpenELEC' in O000OOo00oo :
  return True
  if 17 - 17: II1 + IIiIiiIi * o00oooO0Oo * IIiIi1iI
  if 36 - 36: OOO0O0O0ooooo + Ii11II1iII1I1
def iIIIi1i1I11i ( name , zip_link , repo_link , repo_id , addon_id , provider_name , forum , data_path ) :
 forum = str ( forum )
 repo_id = str ( repo_id )
 oOO0OO0OO = 1
 oOOoooO = 1
 i1ii11 = 1
 OOoOO0oo00Oo = xbmc . translatePath ( os . path . join ( iIii1 , addon_id ) )
 if 49 - 49: II1 / i11iIiiIii * i11iIiiIii
 if os . path . exists ( OOoOO0oo00Oo ) :
  Ii1ii1IiIII = 1
  if 58 - 58: OOooo0O00o
 else :
  Ii1ii1IiIII = 0
  if 4 - 4: ooo0oo0o0oo . i1Iii1i1I / I11i1ii1 - i11iIiiIii
 OoO00 = xbmc . translatePath ( os . path . join ( o00OO00OoO , name + '.zip' ) )
 I11iIi1II = xbmc . translatePath ( os . path . join ( iIii1 , addon_id ) )
 if 60 - 60: IIii1I + O00ooooo00
 oO . create ( "Installing Addon" , "Please wait whilst your addon is installed" , '' , '' )
 if 86 - 86: IIii1I + IIiIi1iI . i11iIiiIii - o0O0OOO0Ooo
 try :
  downloader . download ( repo_link , OoO00 , oO )
  oOoooo0O0Oo ( OoO00 , iIii1 , oO )
  if 51 - 51: IIiIi1iI
 except :
  if 14 - 14: ii % OOooo0O00o % Ii11II1iII1I1 - i11iIiiIii
  try :
   downloader . download ( zip_link , OoO00 , oO )
   oOoooo0O0Oo ( OoO00 , iIii1 , oO )
   if 53 - 53: o0O0OOO0Ooo % Ii11II1iII1I1
  except :
   if 59 - 59: IIiIiiIi % IIii1I . O00ooooo00 + ooo0oo0o0oo * ii
   try :
    if not os . path . exists ( I11iIi1II ) :
     os . makedirs ( I11iIi1II )
     if 41 - 41: o0O0OOO0Ooo % I11i1ii1
    OOO = Oo0O0 ( data_path ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
    i1iIiIi1I = re . compile ( 'href="(.+?)"' , re . DOTALL ) . findall ( OOO )
    if 37 - 37: o0O0OOO0Ooo % oOOo0
    for oOooO0 in i1iIiIi1I :
     O0O0ooOOO = xbmc . translatePath ( os . path . join ( I11iIi1II , oOooO0 ) )
     if 70 - 70: i1Iii1i1I . OOO0O0O0ooooo . IiiIIIiI . OOO0O0O0ooooo + O00ooooo00
     if addon_id not in oOooO0 and '/' not in oOooO0 :
      if 9 - 9: Ii11II1iII1I1
      try :
       oO . update ( 0 , "Downloading [COLOR=darkcyan]" + oOooO0 + '[/COLOR]' , '' , 'Please wait...' )
       downloader . download ( data_path + oOooO0 , O0O0ooOOO , oO )
       if 99 - 99: o00oooO0Oo - IiiIIIiI - OOooo0O00o % oOOo0
      except :
       print "failed to install" + oOooO0
       if 21 - 21: ooo0oo0o0oo % I11i1ii1 . O00ooooo00 - II1
     if '/' in oOooO0 and '..' not in oOooO0 and 'http' not in oOooO0 :
      iiOOOO0o = data_path + oOooO0
      Recursive_Loop ( O0O0ooOOO , iiOOOO0o )
      if 10 - 10: IiiIIIiI % iiiii1I1I1I
   except :
    dialog . ok ( "Error downloading add-on" , 'There was an error downloading [COLOR=darkcyan]' + name , '[/COLOR]Please consider updating the add-on portal with details or report the error on the forum at [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B]' )
    oOO0OO0OO = 0
    if 97 - 97: II1 - IiiIIIiI
 if oOO0OO0OO == 1 :
  time . sleep ( 1 )
  oO . update ( 0 , "[COLOR=darkcyan]" + name + '[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]' , '' , 'Now installing repository' )
  time . sleep ( 1 )
  I1iiIIIi11 = xbmc . translatePath ( os . path . join ( iIii1 , repo_id ) )
  if 58 - 58: IIii1I + OOO0O0O0ooooo
  if ( repo_id != 'repository.xbmc.org' ) and not ( os . path . exists ( I1iiIIIi11 ) ) and ( repo_id != '' ) and ( 'superrepo' not in repo_id ) :
   Install_Repo ( repo_id )
   if 30 - 30: i1Iii1i1I % OOOO00O0O * IIiIiiIi - I11i1ii1 * o0O0OOO0Ooo % i1Iii1i1I
  xbmc . sleep ( 2000 )
  if 46 - 46: i11iIiiIii - OOO0O0O0ooooo . OOooo0O00o
  if os . path . exists ( OOoOO0oo00Oo ) and Ii1ii1IiIII == 0 :
   oOIIi1iiii1iI = 'http://totalxbmc.com/TI/AddonPortal/downloadcount.php?id=%s' % ( addon_id )
   Oo0O0 ( oOIIi1iiii1iI )
   if 100 - 100: iiiii1I1I1I / i1IiiiI1iI * OOOO00O0O . OOO0O0O0ooooo / IIiIiiIi
  Dependency_Install ( name , addon_id )
  xbmc . executebuiltin ( 'UpdateLocalAddons' )
  xbmc . sleep ( 1000 )
  xbmc . executebuiltin ( 'UpdateAddonRepos' )
  if 83 - 83: IiiIIIiI
  if oOOoooO == 0 :
   dialog . ok ( name + " Install Complete" , 'The add-on has been successfully installed but' , 'there was an error installing the repository.' , 'This will mean the add-on fails to update' )
   if 48 - 48: ooo0oo0o0oo * IIiIiiIi * IiiIIIiI
  if i1ii11 == 0 :
   dialog . ok ( name + " Install Complete" , 'The add-on has been successfully installed but' , 'there was an error installing modules.' , 'This could result in errors with the add-on.' )
   if 50 - 50: ii % O00ooooo00
  if i1ii11 != 0 and oOOoooO != 0 and forum != 'None' :
   dialog . ok ( name + " Install Complete" , 'Please support the developer(s) [COLOR=dodgerblue]' + provider_name , '[/COLOR]Support for this add-on can be found at [COLOR=darkcyan]' + forum , '[/COLOR][CR]Visit [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR] for all your Kodi needs.' )
   if 21 - 21: II1 - IIii1I
  if i1ii11 != 0 and oOOoooO != 0 and forum == 'None' :
   dialog . ok ( name + " Install Complete" , 'Please support the developer(s) [COLOR=dodgerblue]' + provider_name , '[/COLOR]No details of forum support have been given.' )
   if 93 - 93: OOooo0O00o - i1IiiiI1iI % IIiIi1iI . IIiIi1iI - i1Iii1i1I
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 90 - 90: i1Iii1i1I + ooo0oo0o0oo * I11i1ii1 / o0O0OOO0Ooo . i1IiiiI1iI + i1IiiiI1iI
if not os . path . exists ( o0OO00oO ) :
 os . makedirs ( o0OO00oO )
 if 40 - 40: i1Iii1i1I / IIiIi1iI % i11iIiiIii % I11i1ii1 / iiiii1I1I1I
if not os . path . exists ( ii11iIi1I ) :
 os . makedirs ( ii11iIi1I )
 if 62 - 62: O00ooooo00 - IIiIi1iI
if not os . path . exists ( I11II1i ) :
 O00OOOoOoo0O = open ( I11II1i , mode = 'w+' )
 O00OOOoOoo0O . write ( 'date="01011001"\nversion="0.0"' )
 O00OOOoOoo0O . close ( )
 if 62 - 62: O00ooooo00 + Ii11II1iII1I1 % ii
if not os . path . exists ( ooooooO0oo ) :
 O00OOOoOoo0O = open ( ooooooO0oo , mode = 'w+' )
 O00OOOoOoo0O . write ( 'id="None"\nname="None"' )
 O00OOOoOoo0O . close ( )
 if 28 - 28: I11i1ii1 . O00ooooo00
if not os . path . exists ( IIiiiiiiIi1I1 ) :
 O00OOOoOoo0O = open ( IIiiiiiiIi1I1 , mode = 'w+' )
 O00OOOoOoo0O . write ( 'line="1"' )
 O00OOOoOoo0O . close ( )
 if 10 - 10: oOOo0 / Ii11II1iII1I1
if __name__ == '__main__' :
 oo00O00oO ( 'url' ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
