import default
print"### Starting Update Check E"
default.Check_Update_Launcher('e')