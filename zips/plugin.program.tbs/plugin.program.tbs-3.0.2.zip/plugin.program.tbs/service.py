import re, xbmcplugin, xbmcgui, xbmc, xbmcaddon, os, sys, time

######################################################
AddonID='plugin.program.tbs'
AddonName='Maintenance'
######################################################
ADDON            =  xbmcaddon.Addon(id=AddonID)
dialog           =  xbmcgui.Dialog()
dp               =  xbmcgui.DialogProgress()
HOME             =  xbmc.translatePath('special://home/')
USERDATA         =  xbmc.translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA       =  xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
ADDONS           =  xbmc.translatePath(os.path.join('special://home','addons',''))
idfile           =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'id.xml'))
sleeper          =  os.path.join(ADDONS,AddonID,'resources','tmr')
internetcheck    =  ADDON.getSetting('internetcheck')
cachecheck       =  ADDON.getSetting('cleancache')
cbnotifycheck    =  ADDON.getSetting('cbnotifycheck')
mynotifycheck    =  ADDON.getSetting('mynotifycheck')
TBSDATA          =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,''))
#---------------------------------------------------------------------------------------------------
if not os.path.exists(TBSDATA):
    os.makedirs(TBSDATA)

if not os.path.exists(idfile):
    localfile = open(idfile, mode='w+')
    localfile.write('id="None"\nname="None"')
    localfile.close()
    
if internetcheck == 'true':
    xbmc.executebuiltin('XBMC.AlarmClock(internetloop,XBMC.RunScript(special://home/addons/'+AddonID+'/connectivity.py,silent=true),00:01:00,silent,loop)')

if cachecheck == 'true':
    xbmc.executebuiltin('XBMC.AlarmClock(cleancacheloop,XBMC.RunScript(special://home/addons/'+AddonID+'/cleancache.py,silent=true),12:00:00,silent,loop)')

readfile = open(sleeper, 'r')
sleep = readfile.read()
readfile.close()

xbmc.executebuiltin('XBMC.AlarmClock(Notifyloop,XBMC.RunScript(special://home/addons/'+AddonID+'/checknews.py,silent=true),'+sleep+',silent,loop)')