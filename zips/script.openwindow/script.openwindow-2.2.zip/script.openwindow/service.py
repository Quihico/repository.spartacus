import xbmc

RUN_WIZARD = xbmc.translatePath('special://home/addons/packages/RUN_WIZARD')

def Start_Updates():
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.tbs/checknews.py,service)')

while xbmc.Player().isPlaying():
    xbmc.sleep(500)

xbmc.executebuiltin('RunScript(special://home/addons/script.openwindow/default.py,service)')