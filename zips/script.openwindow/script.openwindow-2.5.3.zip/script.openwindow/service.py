#       Copyright (C) 2016 TotalRevolution
#
#  This software is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International Public License
#  You can find a copy of the license in the add-on folder

import os
import xbmc

UNREGISTERED   = xbmc.translatePath('special://profile/addon_data/script.openwindow/unregistered')
PACKAGES   	   = xbmc.translatePath('special://home/addons/packages')
RUN_WIZARD     = os.path.join(PACKAGES,'RUN_WIZARD')
STARTUP_WIZARD = os.path.join(PACKAGES, 'STARTUP_WIZARD')

while xbmc.Player().isPlaying():
    xbmc.sleep(500)

if not os.path.exists(PACKAGES):
	os.makedirs(PACKAGES)

if not os.path.exists(STARTUP_WIZARD) and not os.path.exists(RUN_WIZARD):
	os.makedirs(RUN_WIZARD)

if os.path.exists(RUN_WIZARD):
    if os.path.exists(xbmc.translatePath('special://home/addons/script.openwindow/default.py')):
        xbmc.executebuiltin('RunScript(special://home/addons/script.openwindow/default.py,service)')
    else:
        xbmc.executebuiltin('RunScript(special://xbmc/addons/script.openwindow/default.py,service)')