import xbmc

RUN_WIZARD = xbmc.translatePath('special://home/addons/packages/RUN_WIZARD')

while xbmc.Player().isPlaying():
    xbmc.sleep(500)

try:
    xbmc.executebuiltin('special://home/addons/script.openwindow/default.py,service)')
except:
    xbmc.executebuiltin('special://xbmc/addons/script.openwindow/default.py,service)')